# Effect of rare species removal on species groups ----

crusF <- function(Ymat,     # site x species data frame
                  flim = 1, # maximum relative species frequency
                  spmin = 5 # minimum number of species
                  ) {
  # Species frequencies
  spf <- colSums(Ymat > 0)
  # Vector of ordered species frequencies
  fm <- sort(unique(spf[spf <= flim * nrow(Ymat)]))
  sper <-
    data.frame(
      Fmina = fm, # absolute minimum frequency
      Fminr = 100 * fm / nrow(Ymat), # relative minimum frequency
      Nsp = 0,    # number of species
      Nempty = 0, # number of empty sites
      Prop0 = 0)  # proportion of zeros
  # Rare species removal
  for (i in 1:nrow(sper)) {
    # Total number of species remaining
    sper$Nsp[i] <- sum(spf >= sper$Fmina[i])
    if (sper$Nsp[i] > 1) {
      # Remove species with frequency lower than fm
      YY <- Ymat[, spf >= sper$Fmina[i]]
      # Number of empty sites
      sper$Nempty[i] <- sum(rowSums(YY) == 0)
      if (!any(rowSums(YY) == 0))
        sper$Prop0[i] <- sum(YY == 0) / (nrow(YY) * ncol(YY))
    }
  }
  # Discard matrices with less than spmin species
  sper <- sper[sper$Nsp >= spmin, ]
  # Discard matrices with empty sites
  sper <- sper[sper$Nempty == 0, ]
  # Number of core, rural, urban and satellite species
  no <- remF(Ymat, sper)
  return(no)
}

# Number of core, rural, urban and satellite species
remF <- function(Ymat, sper) {
  # Species frequencies
  spf <- colSums(Ymat > 0)
  simul <- data.frame(
    sper,
    core = 0,
    rura = 0,
    urba = 0,
    sate = 0,
    crus = 0)
  for (i in 1:nrow(simul)) {
    YY <- Ymat[, spf >= simul$Fmina[i]]
    # YY <- YY[rowSums(YY) > 0, ]
    # Species absolute frequency (number of sites occupied)
    fr <- colSums(YY > 0)
    # Species occupancy (proportion of sites occupied)
    frel <- fr / nrow(YY)
    # Relative abundance
    vegr <- decostand(YY, "total")
    # Average relative cover (when present)
    av2d <- colSums(vegr) / fr
    simul$core[i] <- length(names(YY)[frel >= 0.5 & av2d >= 0.05])
    simul$rura[i] <- length(names(YY)[frel >= 0.5 & av2d < 0.05])
    simul$urba[i] <- length(names(YY)[frel < 0.5 & av2d >= 0.05])
    simul$sate[i] <- length(names(YY)[frel < 0.5 & av2d < 0.05])
    simul$crus[i] <-
      simul$core[i] + simul$rura[i] + simul$urba[i] + simul$sate[i]
  }
  return(simul)
}



# Effect of sparse species removal on species groups ----

crusA <- function(Ymat,            # site x species data frame
                  abmax = 1,       # maximum species abundance (0 to 1)
                  interval = 0.02, # interval of abundance
                  spmin = 5        # minimum number of species
                  ) {
  # Data frame of relative abundances (0 to 1)
  Yr <- decostand(Ymat, "total")
  # Vector of ordered species abundances
  fm <- seq(0, abmax, by = interval)
  sper <- data.frame(Fminr = fm * 100, # ordered relative abundances
                     Nsp = 0,      # number of species
                     Nempty = 0,   # number of empty sites
                     Prop0 = 0     # proportion of zeros
                     )
  for (i in 1:nrow(sper)) {
    YY <- Ymat
    # Remove species with lower relative abundance than fm
    YY[Yr < fm[i]] <- 0
    # Total number of species remaining
    sper$Nsp[i] <- sum(colSums(YY) > 0)
    if (sper$Nsp[i] > 1) {
      YY <- YY[, colSums(YY) > 0]
      # Number of empty sites
      sper$Nempty[i] <- sum(rowSums(YY) == 0)
      if (!any(rowSums(YY) == 0))
        sper$Prop0[i] <- sum(YY == 0) / (nrow(YY) * ncol(YY))
    }
  }
  # Discard matrices with less than spmin species
  sper <- sper[sper$Nsp >= spmin, ]
  # Discard matrices with empty sites
  sper <- sper[sper$Nempty == 0, ]
  # Number of core, rural, urban and satellite species
  no <- remA(Ymat, sper)
  return(no)
}

# Number of core, rural, urban and satellite species
remA <- function(Ymat, sper) {
  Yr <- 100 * decostand(Ymat, "total")	# relative abundance (% cover)
  spf <- colSums(Ymat > 0)
  simul <- data.frame(
    sper,
    core = 0,
    rura = 0,
    urba = 0,
    sate = 0,
    crus = 0)
  for (i in 1:nrow(simul)) {
    YY <- Ymat
    YY[Yr < simul$Fminr[i]] <- 0
    YY <- YY[, colSums(YY) > 0]
    # YY <- YY[rowSums(YY) > 0, ]
    # Species absolute frequency (number of sites occupied)
    fr <- colSums(YY > 0)
    # Species occupancy (proportion of sites occupied)
    frel <- fr / nrow(YY)
    # Relative abundance
    vegr <- decostand(YY, "total")
    # Average relative cover (when present)
    av2d <- colSums(vegr) / fr
    simul$core[i] <- length(names(YY)[frel >= 0.5 & av2d >= 0.05])
    simul$rura[i] <- length(names(YY)[frel >= 0.5 & av2d < 0.05])
    simul$urba[i] <- length(names(YY)[frel < 0.5 & av2d >= 0.05])
    simul$sate[i] <- length(names(YY)[frel < 0.5 & av2d < 0.05])
    simul$crus[i] <-
      simul$core[i] + simul$rura[i] + simul$urba[i] + simul$sate[i]
  }
  return(simul)
}



# RDA outputs ----

resRDA <- function(Ymat, Xmat) {
  require(vegan)
  # Xmat <- Xmat[rownames(Ymat), ] # as a precaution!
  mod <- rda(Ymat ~ ., Xmat)
  ev <- mod$CCA$eig
  p <- anova(mod, step = 1000)$Pr
  p1 <- anova(mod, step = 1000, first = TRUE)$Pr
  aic <- extractAIC(mod)
  R2 <- RsquareAdj(mod)$r.squared
  R2adj <- RsquareAdj(mod)$adj.r.squared
  ax1 <- ev[1] / sum(ev) * R2adj
  ax2 <- ev[2] / sum(ev) * R2adj
  return(c(R2, R2adj, aic[2], p[1], p1[1], ax1, ax2))
}


# Effect of rare species removal on RDA and diversity indices ----

remsplistF <- function(Ymat, 
                       Xmat, 
                       flim = 1, 
                       spmin = 5) {
  # Ymat is the species data frame (raw abundances = absolute percentage cover)
  # Xmat is the environmental data frame
  # flim is the highest minimum relative frequency
  # spmin is the minimum number of species remaining at the end of the 
  # removal process (should be > 1)
  spf <- colSums(Ymat > 0)
  fm <- sort(unique(spf[spf <= flim * nrow(Ymat)]))
  sper <-
    data.frame(
      Fmina = fm, # unique minimum absolute frequency (number of sites occupied)
      Fminr = 100 * fm / nrow(Ymat), # minimum occupancy (%)
      Nsp = 0,    # total number of remaining species
      Nempty = 0, # number of empty sites
      Prop0 = 0   # proportion of zeros
    )
  for (i in 1:nrow(sper)) {
    sper$Nsp[i] <- sum(spf >= sper$Fmina[i])
    if (sper$Nsp[i] > 1) { # check if at least one species remain in the dataset
      # Remove species
      YY <- Ymat[, spf >= sper$Fmina[i]]
      # Number of empty sites
      sper$Nempty[i] <- sum(rowSums(YY) == 0)
      if (!any(rowSums(YY) == 0)) # check if no site is empty
        sper$Prop0[i] <- sum(YY == 0) / (nrow(YY) * ncol(YY))
    }
  }
  # Discard matrices with less than spmin species
  sper <- sper[sper$Nsp >= spmin, ]
  # Discard matrices with empty sites
  sper <- sper[sper$Nempty == 0, ]
  
  # Compute diversity and ordination analyses
  no <- remspF(Ymat, Xmat, sper, transfo = "none")
  sq <- remspF(Ymat, Xmat, sper, transfo = "sqrt")
  lo <- remspF(Ymat, Xmat, sper, transfo = "log")
  pa <- remspF(Ymat, Xmat, sper, transfo = "pa")
  oc <- remspF(Ymat, Xmat, sper, transfo = "ochiai")
  ch <- remspF(Ymat, Xmat, sper, transfo = "chord")
  he <- remspF(Ymat, Xmat, sper, transfo = "hell")
  kh <- remspF(Ymat, Xmat, sper, transfo = "chisq")
  return(list(
    no = no,
    sq = sq,
    lo = lo,
    pa = pa,
    oc = oc,
    ch = ch,
    he = he,
    kh = kh
  ))
}

# Diversity and ordination analyses
remspF <-
  function(Ymat,
           Xmat,
           sper,
           transfo = c("none", "sqrt", "log", "pa", "ochiai",
                       "chord", "hell", "chisq")) {
    spf <- colSums(Ymat > 0) # species frequencies
    simul <-
      data.frame(
        sper,
        R2 = 0,
        adjR2 = 0,
        AIC = 0,
        p = 0,
        p1 = 0,
        axis1 = 0,
        axis2 = 0,
        N0alpha = 0,
        N0beta = 0,
        N0gamma = 0,
        N1alpha = 0,
        N1beta = 0,
        N1gamma = 0,
        N2alpha = 0,
        N2beta = 0,
        N2gamma = 0,
        Mhom0 = 0,
        Mhom1 = 0,
        Mhom2 = 0)
    for (i in 1:nrow(simul)) {
      YY <- Ymat[, spf >= simul$Fmina[i]]
      # YY <- YY[rowSums(YY) > 0, ]
      if (transfo == "sqrt")
        YY <- sqrt(YY)
      if (transfo == "log")
        YY <- log1p(YY)
      if (transfo == "pa")
        YY <- decostand(YY, "pa")
      if (transfo == "ochiai")
        YY <- decostand(decostand(YY, "pa"), "norm")
      if (transfo == "chord")
        YY <- decostand(YY, "norm")
      if (transfo == "hell")
        YY <- decostand(YY, "hell")
      if (transfo == "chisq")
        YY <- decostand(YY, "chi")
      simul[i, 6:12] <- resRDA(YY, Xmat)
      simul$N0alpha[i] <- d(YY, lev = "alpha", q = 0)
      simul$N1alpha[i] <- d(YY, lev = "alpha", q = 1)
      simul$N2alpha[i] <- d(YY, lev = "alpha", q = 2)
      simul$N0beta[i] <- d(YY, lev = "beta", q = 0)
      simul$N1beta[i] <- d(YY, lev = "beta", q = 1)
      simul$N2beta[i] <- d(YY, lev = "beta", q = 2)
      simul$N0gamma[i] <- d(YY, lev = "gamma", q = 0)
      simul$N1gamma[i] <- d(YY, lev = "gamma", q = 1)
      simul$N2gamma[i] <- d(YY, lev = "gamma", q = 2)
      simul$Mhom0[i] <- M.homog(YY, q = 0, std = TRUE)
      simul$Mhom1[i] <- M.homog(YY, q = 1, std = TRUE)
      simul$Mhom2[i] <- M.homog(YY, q = 2, std = TRUE)
    }
    return(simul)
  }



# Effect of sparse species removal on RDA and diversity indices ----

remsplistA <- function(Ymat,
                       Xmat,
                       abmax = 1,
                       interval = 0.02,
                       spmin = 5) {
  # Ymat is the species data frame (raw abundances = absolute percentage cover)
  # Xmat is the environmental data frame
  # abmax is the highest minimum relative abundance
  # interval is the interval of minimum relative abundance between successive removals
  # spmin is the minimum number of species remaining at the end of the removal process
  Yr <- decostand(Ymat, "total")	     # relative abundance
  fm <- seq(0, abmax, by = interval)   # sequence of minimum relative abundances
  sper <- data.frame(Fminr = 100 * fm, # minimum percent cover
                     Nsp = 0,          # total number of remaining species
                     Nempty = 0,       # number of empty sites
                     Prop0 = 0         # proportion of zeros
                     )     
  for (i in 1:nrow(sper)) {
    YY <- Ymat
    YY[Yr < fm[i]] <- 0 # set to 0 all values below a minimum relative abundance
    sper$Nsp[i] <- sum(colSums(YY) > 0)
    if (sper$Nsp[i] > 1) { # check if at least one species remain in the dataset
      # Remove empty species
      YY <- YY[, colSums(YY) > 0]
      # Number of empty sites
      sper$Nempty[i] <- sum(rowSums(YY) == 0)
      if (!any(rowSums(YY) == 0)) # check if no site is empty
        sper$Prop0[i] <- sum(YY == 0) / (nrow(YY) * ncol(YY))
    }
  }
  # Discard matrices with less than spmin species
  sper <- sper[sper$Nsp >= spmin, ]
  # Discard matrices with empty sites
  sper <- sper[sper$Nempty == 0, ]
  
  # Compute diversity and ordination analyses
  no <- remspA(Ymat, Xmat, sper, transfo = "none")
  sq <- remspA(Ymat, Xmat, sper, transfo = "sqrt")
  lo <- remspA(Ymat, Xmat, sper, transfo = "log")
  pa <- remspA(Ymat, Xmat, sper, transfo = "pa")
  oc <- remspA(Ymat, Xmat, sper, transfo = "ochiai")
  ch <- remspA(Ymat, Xmat, sper, transfo = "chord")
  he <- remspA(Ymat, Xmat, sper, transfo = "hell")
  kh <- remspA(Ymat, Xmat, sper, transfo = "chisq")
  return(list(
    no = no,
    sq = sq,
    lo = lo,
    pa = pa,
    oc = oc,
    ch = ch,
    he = he,
    kh = kh
  ))
}

# Diversity and ordination analyses
remspA <-
  function(Ymat,
           Xmat,
           sper,
           transfo = c("none", "sqrt", "log", "pa", "ochiai",
                       "chord", "hell", "chisq")) {
    Yr <- 100 * decostand(Ymat, "total")	# relative abundance (% cover)
    spf <- colSums(Ymat > 0)
    simul <-
      data.frame(
        sper,
        R2 = 0,
        adjR2 = 0,
        AIC = 0,
        p = 0,
        p1 = 0,
        axis1 = 0,
        axis2 = 0,
        N0alpha = 0,
        N0beta = 0,
        N0gamma = 0,
        N1alpha = 0,
        N1beta = 0,
        N1gamma = 0,
        N2alpha = 0,
        N2beta = 0,
        N2gamma = 0,
        Mhom0 = 0,
        Mhom1 = 0,
        Mhom2 = 0)
    for (i in 1:nrow(simul)) {
      YY <- Ymat
      YY[Yr < simul$Fminr[i]] <- 0
      YY <- YY[, colSums(YY) > 0]
      # YY <- YY[rowSums(YY) > 0, ]
      if (transfo == "sqrt")
        YY <- sqrt(YY)
      if (transfo == "log")
        YY <- log1p(YY)
      if (transfo == "pa")
        YY <- decostand(YY, "pa")
      if (transfo == "ochiai")
        YY <- decostand(decostand(YY, "pa"), "norm")
      if (transfo == "chord")
        YY <- decostand(YY, "norm")
      if (transfo == "hell")
        YY <- decostand(YY, "hell")
      if (transfo == "chisq")
        YY <- decostand(YY, "chi")
      simul[i, 5:11] <- resRDA(YY, Xmat)
      simul$N0alpha[i] <- d(YY, lev = "alpha", q = 0)
      simul$N1alpha[i] <- d(YY, lev = "alpha", q = 1)
      simul$N2alpha[i] <- d(YY, lev = "alpha", q = 2)
      simul$N0beta[i] <- d(YY, lev = "beta", q = 0)
      simul$N1beta[i] <- d(YY, lev = "beta", q = 1)
      simul$N2beta[i] <- d(YY, lev = "beta", q = 2)
      simul$N0gamma[i] <- d(YY, lev = "gamma", q = 0)
      simul$N1gamma[i] <- d(YY, lev = "gamma", q = 1)
      simul$N2gamma[i] <- d(YY, lev = "gamma", q = 2)
      simul$Mhom0[i] <- M.homog(YY, q = 0, std = TRUE)
      simul$Mhom1[i] <- M.homog(YY, q = 1, std = TRUE)
      simul$Mhom2[i] <- M.homog(YY, q = 2, std = TRUE)
    }
    return(simul)
  }
