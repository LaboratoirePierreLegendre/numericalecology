# Packages and functions ----

# Load required packages
library(ade4)
library(vegan)
library(vegetarian)

# Source additional functions
source("0-functions.R")

# Set up dataset parameters
params <- data.frame(dataset = c("vare", "catgrass", "dune", 
                                 "trufe", "vltava", "bryce"),
                     flim = 1,
                     abmax = 1,
                     interval = 0.02,
                     spmin = 5)


# Occupancy and abundance ----

for (i in 1:nrow(params)) {
  
  load(paste0(params$dataset[i], ".RData"))
  
  # Number of plots (assemblages)
  params$nSites[i] <- nrow(spe)
  # Total number of species
  params$nSpe[i] <- ncol(spe)
  # Percentage of zeros in the species matrix
  params$zeros[i] <- 100 * sum(spe == 0) / (ncol(spe) * nrow(spe))
  # Minimum and maximum species richness
  params$N0min[i] <- min(rowSums(spe > 0))
  params$N0max[i] <- max(rowSums(spe > 0))
  
  # Species absolute frequency (number of sites occupied)
  fr <- colSums(spe > 0)
  # Species occupancy (proportion of sites occupied)
  frel <- fr / nrow(spe)
  # Relative abundance-cover
  sperel <- decostand(spe, "total")
  # Average relative cover (when present)
  avc <- colSums(sperel) / fr
  # sort(round(100 * avc, 2), decreasing = TRUE)
  
  # Linear correlation between occupancy and abundance
  params$r[i] <- cor(frel, avc)
  # Spearman correlation between occupancy and abundance
  params$rho[i] <- cor(frel, avc, method = "spearman")
  # Number of unique species
  params$uniques[i] <- sum(fr == 1)
 
  # Save occupancy-abundance data for further synthesis
  ocdo <- data.frame(occupancy = 100 * frel, dominance = 100 * avc)
  save(ocdo, file = paste0(params$dataset[i], "_ocdo.RData"))
  
  # Core, rural, urban and satellite species
  params$core[i] <- length(names(spe)[frel >= 0.5 & avc >= 0.05])
  params$rura[i] <- length(names(spe)[frel >= 0.5 & avc < 0.05])
  params$urba[i] <- length(names(spe)[frel < 0.5 & avc >= 0.05])
  params$sate[i] <- length(names(spe)[frel < 0.5 & avc < 0.05])
  params$crus[i] <-
    params$core[i] + params$rura[i] + params$urba[i] + params$sate[i]
  
  # Species exclusion based on occupancy (frequency of occurrence)
  cF <- crusF(spe, flim = params$flim[i], spmin = params$spmin[i])
  save(cF, file = paste0(params$dataset[i], "_crusF.RData"))
  # Species exclusion based on abundance (by site)
  cA <- crusA(spe, abmax = params$abmax[i], interval = params$interval[i],
              spmin = params$spmin[i])
  save(cA, file = paste0(params$dataset[i], "_crusA.RData"))
  
  # Diversity indices (Hill numbers)
  params$N0alpha[i] <- d(spe, lev = "alpha", q = 0)
  params$N1alpha[i] <- d(spe, lev = "alpha", q = 1)
  params$N2alpha[i] <- d(spe, lev = "alpha", q = 2)
  params$N0beta[i] <- d(spe, lev = "beta", q = 0)
  params$N1beta[i] <- d(spe, lev = "beta", q = 1)
  params$N2beta[i] <- d(spe, lev = "beta", q = 2)
  params$N0gamma[i] <- d(spe, lev = "gamma", q = 0)
  params$N1gamma[i] <- d(spe, lev = "gamma", q = 1)
  params$N2gamma[i] <- d(spe, lev = "gamma", q = 2)
  params$Mhom0[i] <- M.homog(spe, q = 0, std = TRUE)
  params$Mhom1[i] <- M.homog(spe, q = 1, std = TRUE)
  params$Mhom2[i] <- M.homog(spe, q = 2, std = TRUE)
}

# Parameters and Table 1
write.csv2(params, file = "params.csv")



# Effect of species removal on beta-diversity and RDA ----

### BEWARE: long computation time (> 20 minutes)!

for (i in 1:nrow(params)) {
  load(paste0(params$dataset[i], ".RData"))
  
  # First, convert absolute % cover to relative % cover???
  # spe <- decostand(spe, "total") * 100
  
  # Species removal based on occupancy (frequency of occurrence)
  lsF <- remsplistF(spe, env, flim = params$flim[i], spmin = params$spmin[i])
  save(lsF, file = paste0(params$dataset[i], "_listF.RData"))
  
  # Species removal based on relative abundance (by site)
  lsA <- remsplistA(spe,
                    env,
                    abmax = params$abmax[i],
                    interval = params$interval[i],
                    spmin = params$spmin[i])
  save(lsA, file = paste0(params$dataset[i], "_listA.RData"))
}
