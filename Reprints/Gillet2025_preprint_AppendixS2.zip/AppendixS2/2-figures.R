# Required packages ----

library(tidyverse)
library(cowplot)
library(ggpubr)
library(vegan)


# Internal functions ----

extractR2 <- function(srdlist) {
  r2no <- srdlist$no %>% select(Fminr, adjR2, p) %>%
    mutate(Data = "raw abundance")
  r2pa <- srdlist$pa %>% select(Fminr, adjR2, p) %>%
    mutate(Data = "presence-absence")
  r2oc <- srdlist$oc %>% select(Fminr, adjR2, p) %>%
    mutate(Data = "Ochiai")
  r2he <- srdlist$he %>% select(Fminr, adjR2, p) %>%
    mutate(Data = "Hellinger")
  r2kh <- srdlist$kh %>% select(Fminr, adjR2, p) %>%
    mutate(Data = "chi-square")
  r2 <- rbind(r2no, r2pa, r2oc, r2he, r2kh) %>%
    mutate(pp = ifelse(p < 0.05, 19, 21),
           Data = factor(
             Data,
             levels = c(
               "raw abundance",
               "presence-absence",
               "Ochiai",
               "Hellinger",
               "chi-square"
             )
           ))
  return(r2)
}

extractAx1 <- function(srdlist) {
  c1no <- srdlist$no %>% select(Fminr, adjR2, axis1, p1) %>%
    mutate(Data = "raw abundance")
  c1pa <- srdlist$pa %>% select(Fminr, adjR2, axis1, p1) %>%
    mutate(Data = "presence-absence")
  c1oc <- srdlist$oc %>% select(Fminr, adjR2, axis1, p1) %>%
    mutate(Data = "Ochiai")
  c1he <- srdlist$he %>% select(Fminr, adjR2, axis1, p1) %>%
    mutate(Data = "Hellinger")
  c1kh <- srdlist$kh %>% select(Fminr, adjR2, axis1, p1) %>%
    mutate(Data = "chi-square")
  c1 <- rbind(c1no, c1pa, c1oc, c1he, c1kh) %>%
    mutate(
      RDA1 = 100 * axis1 / adjR2,
      pp = ifelse(p1 < 0.05, 19, 21),
      Data = factor(
        Data,
        levels = c(
          "raw abundance",
          "presence-absence",
          "Ochiai",
          "Hellinger",
          "chi-square"
        )
      )
    )
  return(c1)
}


# Load the processed data ----

load("vare_ocdo.RData")
vare_ocdo <- ocdo %>% mutate(dataset = "vare")
load("catgrass_ocdo.RData")
catgrass_ocdo <- ocdo %>% mutate(dataset = "catgrass")
load("dune_ocdo.RData")
dune_ocdo <- ocdo %>% mutate(dataset = "dune")
load("trufe_ocdo.RData")
trufe_ocdo <- ocdo %>% mutate(dataset = "trufe")
load("vltava_ocdo.RData")
vltava_ocdo <- ocdo %>% mutate(dataset = "vltava")
load("bryce_ocdo.RData")
bryce_ocdo <- ocdo %>% mutate(dataset = "bryce")
ocdo <-
  rbind(vare_ocdo,
        catgrass_ocdo,
        dune_ocdo,
        trufe_ocdo,
        vltava_ocdo,
        bryce_ocdo) %>% 
  mutate(dataset = factor(dataset, levels = c("vare", "catgrass", "dune", 
                                              "trufe", "vltava", "bryce")))

load("vare_crusF.RData")
vare_crusF <- cF
load("vare_crusA.RData")
vare_crusA <- cA
load("catgrass_crusF.RData")
catgrass_crusF <- cF
load("catgrass_crusA.RData")
catgrass_crusA <- cA
load("dune_crusF.RData")
dune_crusF <- cF
load("dune_crusA.RData")
dune_crusA <- cA
load("trufe_crusF.RData")
trufe_crusF <- cF
load("trufe_crusA.RData")
trufe_crusA <- cA
load("vltava_crusF.RData")
vltava_crusF <- cF
load("vltava_crusA.RData")
vltava_crusA <- cA
load("bryce_crusF.RData")
bryce_crusF <- cF
load("bryce_crusA.RData")
bryce_crusA <- cA
rm(cA, cF)

load("vare_listF.RData")
varelistF <- lsF
load("vare_listA.RData")
varelistA <- lsA
load("catgrass_listF.RData")
catgrasslistF <- lsF
load("catgrass_listA.RData")
catgrasslistA <- lsA
load("dune_listF.RData")
dunelistF <- lsF
load("dune_listA.RData")
dunelistA <- lsA
load("trufe_listF.RData")
trufelistF <- lsF
load("trufe_listA.RData")
trufelistA <- lsA
load("vltava_listF.RData")
vltavalistF <- lsF
load("vltava_listA.RData")
vltavalistA <- lsA
load("bryce_listF.RData")
brycelistF <- lsF
load("bryce_listA.RData")
brycelistA <- lsA
rm(lsA, lsF)



# Abundance and occupancy ----

## Fig. 1 - Frequency distribution ----

gghistogram(
  ocdo,
  x = "occupancy",
  y = "..density..",
  fill = "dataset",
  color = "dataset",
  bins = 10,
  add = "mean",
  facet.by = "dataset",
  scales = "free_y",
  # yticks.by = 100,
  add_density = TRUE,
  xlab = "Occupancy (%)",
  ylab = "Density",
  legend = "none",
  ggtheme = theme_cowplot()
) +
  theme(
    axis.ticks.y = element_blank(),
    axis.text.y = element_blank(),
    axis.line.y = element_blank()
  )
ggsave("fig1.pdf", width = 7, height = 5)
ggsave("fig1.png", width = 7, height = 5)
ggsave("fig1.svg", width = 7, height = 5)


## Fig. 2 - Abundance vs Occupancy ----

ggscatter(
  ocdo,
  x = "occupancy",
  y = "dominance",
  color = "dataset",
  alpha = 0.5,
  yscale = "log10", 
  add = "reg.line",
  # conf.int = TRUE,
  cor.coef = TRUE,
  cor.coeff.args = list(r.accuracy = 0.001, 
                        p.accuracy = 0.001,
                        label.x = 52,
                        cor.coef.name = "r",
                        label.y.npc = "bottom"), 
  cor.coef.size = 3, 
  facet.by = "dataset",
  # scales = "free_y",
  xlab = "Occupancy (%)",
  ylab = "Abundance (%)",
  legend = "none",
  ggtheme = theme_bw()
) +
  geom_vline(xintercept = 50, linetype = "dashed") +
  geom_hline(yintercept = 5, linetype = "dashed")
ggsave("fig2.pdf", width = 8, height = 5)
ggsave("fig2.png", width = 8, height = 5)
ggsave("fig2.svg", width = 8, height = 5)



# Species groups ----

## Fig. 3 - Barplot crus ----

# Table of crus species counts
crusall <-
  data.frame(
    core = rep(NA, 6),
    rural = NA,
    urban = NA,
    satellite = NA)
rownames(crusall) <-
  c("vare", "catgrass", "dune", "trufe", "vltava", "bryce")
crusall[1, ] <- vare_crusF[1, c("core", "rura", "urba", "sate")]
crusall[2, ] <- catgrass_crusF[1, c("core", "rura", "urba", "sate")]
crusall[3, ] <- dune_crusF[1, c("core", "rura", "urba", "sate")]
crusall[4, ] <- trufe_crusF[1, c("core", "rura", "urba", "sate")]
crusall[5, ] <- vltava_crusF[1, c("core", "rura", "urba", "sate")]
crusall[6, ] <- bryce_crusF[1, c("core", "rura", "urba", "sate")]
crusall
crusallrel <- decostand(crusall, "total")
allcrus <- list(abs = crusall, rel = crusallrel)

crus <- allcrus$rel %>% 
  rownames_to_column(var = "dataset") %>% 
  pivot_longer(cols = -dataset, 
               names_to = "Species", 
               values_to = "Percent") %>% 
  mutate(Percent = 100 * Percent) %>% 
  mutate(Species = factor(Species, 
                          levels = c("satellite", "urban", "rural", "core")))
cols <- c("tomato", "bisque", "lightgreen", "darkgreen")

ggbarplot(crus,
          x = "dataset",
          y = "Percent",
          color = "white",
          size = 0.1,
          fill = "Species",
          palette = cols,
          xlab = "Data set", 
          ylab = "Proportion of species number (%)")
ggsave("fig3.pdf", width = 5, height = 5)
ggsave("fig3.png", width = 5, height = 5)
ggsave("fig3.svg", width = 5, height = 5)


## Fig. 5 - Area plots ----

cFvare <- vare_crusF %>% 
  select(Fminr, core, rura, urba, sate) %>% 
  pivot_longer(cols = -Fminr, names_to = "Group", values_to = "Count") %>% 
  mutate(Group = factor(Group, 
                        levels = c("sate", "urba", "rura", "core"),
                        labels = c("satellite", "urban", "rural", "core")),
         Dataset = "vare")
cFcatgrass <- catgrass_crusF %>% 
  select(Fminr, core, rura, urba, sate) %>% 
  pivot_longer(cols = -Fminr, names_to = "Group", values_to = "Count") %>% 
  mutate(Group = factor(Group, 
                        levels = c("sate", "urba", "rura", "core"),
                        labels = c("satellite", "urban", "rural", "core")),
         Dataset = "catgrass")
cFdune <- dune_crusF %>% 
  select(Fminr, core, rura, urba, sate) %>% 
  pivot_longer(cols = -Fminr, names_to = "Group", values_to = "Count") %>% 
  mutate(Group = factor(Group, 
                        levels = c("sate", "urba", "rura", "core"),
                        labels = c("satellite", "urban", "rural", "core")),
         Dataset = "dune")
cFtrufe <- trufe_crusF %>% 
  select(Fminr, core, rura, urba, sate) %>% 
  pivot_longer(cols = -Fminr, names_to = "Group", values_to = "Count") %>% 
  mutate(Group = factor(Group, 
                        levels = c("sate", "urba", "rura", "core"),
                        labels = c("satellite", "urban", "rural", "core")),
         Dataset = "trufe")
cFvltava <- vltava_crusF %>% 
  select(Fminr, core, rura, urba, sate) %>% 
  pivot_longer(cols = -Fminr, names_to = "Group", values_to = "Count") %>% 
  mutate(Group = factor(Group, 
                        levels = c("sate", "urba", "rura", "core"),
                        labels = c("satellite", "urban", "rural", "core")),
         Dataset = "vltava")
cFbryce <- bryce_crusF %>% 
  select(Fminr, core, rura, urba, sate) %>% 
  pivot_longer(cols = -Fminr, names_to = "Group", values_to = "Count") %>% 
  mutate(Group = factor(Group, 
                        levels = c("sate", "urba", "rura", "core"),
                        labels = c("satellite", "urban", "rural", "core")),
         Dataset = "bryce")
cF <- rbind(cFvare, cFcatgrass, cFdune, cFtrufe, cFvltava, cFbryce) %>% 
  mutate(Dataset = factor(Dataset, levels = c("vare", "catgrass", "dune",
                                              "trufe", "vltava", "bryce")),
         Method = "Rare species removal")
cF

cAvare <- vare_crusA %>% 
  select(Fminr, core, rura, urba, sate) %>% 
  pivot_longer(cols = -Fminr, names_to = "Group", values_to = "Count") %>% 
  mutate(Group = factor(Group, 
                        levels = c("sate", "urba", "rura", "core"),
                        labels = c("satellite", "urban", "rural", "core")),
         Dataset = "vare")
cAcatgrass <- catgrass_crusA %>% 
  select(Fminr, core, rura, urba, sate) %>% 
  pivot_longer(cols = -Fminr, names_to = "Group", values_to = "Count") %>% 
  mutate(Group = factor(Group, 
                        levels = c("sate", "urba", "rura", "core"),
                        labels = c("satellite", "urban", "rural", "core")),
         Dataset = "catgrass")
cAdune <- dune_crusA %>% 
  select(Fminr, core, rura, urba, sate) %>% 
  pivot_longer(cols = -Fminr, names_to = "Group", values_to = "Count") %>% 
  mutate(Group = factor(Group, 
                        levels = c("sate", "urba", "rura", "core"),
                        labels = c("satellite", "urban", "rural", "core")),
         Dataset = "dune")
cAtrufe <- trufe_crusA %>% 
  select(Fminr, core, rura, urba, sate) %>% 
  pivot_longer(cols = -Fminr, names_to = "Group", values_to = "Count") %>% 
  mutate(Group = factor(Group, 
                        levels = c("sate", "urba", "rura", "core"),
                        labels = c("satellite", "urban", "rural", "core")),
         Dataset = "trufe")
cAvltava <- vltava_crusA %>% 
  select(Fminr, core, rura, urba, sate) %>% 
  pivot_longer(cols = -Fminr, names_to = "Group", values_to = "Count") %>% 
  mutate(Group = factor(Group, 
                        levels = c("sate", "urba", "rura", "core"),
                        labels = c("satellite", "urban", "rural", "core")),
         Dataset = "vltava")
cAbryce <- bryce_crusA %>% 
  select(Fminr, core, rura, urba, sate) %>% 
  pivot_longer(cols = -Fminr, names_to = "Group", values_to = "Count") %>% 
  mutate(Group = factor(Group, 
                        levels = c("sate", "urba", "rura", "core"),
                        labels = c("satellite", "urban", "rural", "core")),
         Dataset = "bryce")
cA <- rbind(cAvare, cAcatgrass, cAdune, cAtrufe, cAvltava, cAbryce) %>% 
  mutate(Dataset = factor(Dataset, levels = c("vare", "catgrass", "dune",
                                              "trufe", "vltava", "bryce")),
         Method = "Sparse species removal")
cA

cFA <- rbind(cF, cA)

ggplot(cFA, aes(Fminr, Count, fill = Group)) +
  geom_area() +
  labs(x = "Minimum species occupancy or abundance (%)",
       y = "Number of species") +
  scale_fill_discrete(name = "Species", type = cols) +
  # facet_wrap(vars(Dataset), scales = "free_y") + 
  # scale_x_continuous(breaks = seq(0, 100, by = 20)) +
  facet_grid(rows = vars(Dataset), cols = vars(Method),
             scales = "free") +
  theme_bw()
ggsave("fig5.pdf", width = 7, height = 7)
ggsave("fig5.png", width = 7, height = 7)
ggsave("fig5.svg", width = 7, height = 7)



# Beta diversity assessment ----

## Fig. 6 - Additive partitioning of species richness ----

divFvare <- varelistF$no %>% 
  mutate(N0beta_add = N0gamma - N0alpha) %>% 
  select(Fminr, N0alpha, N0beta_add) %>% 
  pivot_longer(-Fminr, names_to = "Diversity", values_to = "N0") %>% 
  mutate(Diversity = factor(Diversity, levels = c("N0beta_add", "N0alpha"),
                            labels = c("beta", "alpha")),
         Dataset = "vare")
divFcatgrass <- catgrasslistF$no %>% 
  mutate(N0beta_add = N0gamma - N0alpha) %>% 
  select(Fminr, N0alpha, N0beta_add) %>% 
  pivot_longer(-Fminr, names_to = "Diversity", values_to = "N0") %>% 
  mutate(Diversity = factor(Diversity, levels = c("N0beta_add", "N0alpha"),
                            labels = c("beta", "alpha")),
         Dataset = "catgrass")
divFdune <- dunelistF$no %>% 
  mutate(N0beta_add = N0gamma - N0alpha) %>% 
  select(Fminr, N0alpha, N0beta_add) %>% 
  pivot_longer(-Fminr, names_to = "Diversity", values_to = "N0") %>% 
  mutate(Diversity = factor(Diversity, levels = c("N0beta_add", "N0alpha"),
                            labels = c("beta", "alpha")),
         Dataset = "dune")
divFtrufe <- trufelistF$no %>% 
  mutate(N0beta_add = N0gamma - N0alpha) %>% 
  select(Fminr, N0alpha, N0beta_add) %>% 
  pivot_longer(-Fminr, names_to = "Diversity", values_to = "N0") %>% 
  mutate(Diversity = factor(Diversity, levels = c("N0beta_add", "N0alpha"),
                            labels = c("beta", "alpha")),
         Dataset = "trufe")
divFvltava <- vltavalistF$no %>% 
  mutate(N0beta_add = N0gamma - N0alpha) %>% 
  select(Fminr, N0alpha, N0beta_add) %>% 
  pivot_longer(-Fminr, names_to = "Diversity", values_to = "N0") %>% 
  mutate(Diversity = factor(Diversity, levels = c("N0beta_add", "N0alpha"),
                            labels = c("beta", "alpha")),
         Dataset = "vltava")
divFbryce <- brycelistF$no %>% 
  mutate(N0beta_add = N0gamma - N0alpha) %>% 
  select(Fminr, N0alpha, N0beta_add) %>% 
  pivot_longer(-Fminr, names_to = "Diversity", values_to = "N0") %>% 
  mutate(Diversity = factor(Diversity, levels = c("N0beta_add", "N0alpha"),
                            labels = c("beta", "alpha")),
         Dataset = "bryce")
divF <- rbind(divFvare, divFcatgrass, divFdune, 
              divFtrufe, divFvltava, divFbryce) %>% 
  mutate(Dataset = factor(Dataset, levels = c("vare", "catgrass", "dune",
                                              "trufe", "vltava", "bryce")),
         Method = "Rare species removal")

divAvare <- varelistA$no %>% 
  mutate(N0beta_add = N0gamma - N0alpha) %>% 
  select(Fminr, N0alpha, N0beta_add) %>% 
  pivot_longer(-Fminr, names_to = "Diversity", values_to = "N0") %>% 
  mutate(Diversity = factor(Diversity, levels = c("N0beta_add", "N0alpha"),
                            labels = c("beta", "alpha")),
         Dataset = "vare")
divAcatgrass <- catgrasslistA$no %>% 
  mutate(N0beta_add = N0gamma - N0alpha) %>% 
  select(Fminr, N0alpha, N0beta_add) %>% 
  pivot_longer(-Fminr, names_to = "Diversity", values_to = "N0") %>% 
  mutate(Diversity = factor(Diversity, levels = c("N0beta_add", "N0alpha"),
                            labels = c("beta", "alpha")),
         Dataset = "catgrass")
divAdune <- dunelistA$no %>% 
  mutate(N0beta_add = N0gamma - N0alpha) %>% 
  select(Fminr, N0alpha, N0beta_add) %>% 
  pivot_longer(-Fminr, names_to = "Diversity", values_to = "N0") %>% 
  mutate(Diversity = factor(Diversity, levels = c("N0beta_add", "N0alpha"),
                            labels = c("beta", "alpha")),
         Dataset = "dune")
divAtrufe <- trufelistA$no %>% 
  mutate(N0beta_add = N0gamma - N0alpha) %>% 
  select(Fminr, N0alpha, N0beta_add) %>% 
  pivot_longer(-Fminr, names_to = "Diversity", values_to = "N0") %>% 
  mutate(Diversity = factor(Diversity, levels = c("N0beta_add", "N0alpha"),
                            labels = c("beta", "alpha")),
         Dataset = "trufe")
divAvltava <- vltavalistA$no %>% 
  mutate(N0beta_add = N0gamma - N0alpha) %>% 
  select(Fminr, N0alpha, N0beta_add) %>% 
  pivot_longer(-Fminr, names_to = "Diversity", values_to = "N0") %>% 
  mutate(Diversity = factor(Diversity, levels = c("N0beta_add", "N0alpha"),
                            labels = c("beta", "alpha")),
         Dataset = "vltava")
divAbryce <- brycelistA$no %>% 
  mutate(N0beta_add = N0gamma - N0alpha) %>% 
  select(Fminr, N0alpha, N0beta_add) %>% 
  pivot_longer(-Fminr, names_to = "Diversity", values_to = "N0") %>% 
  mutate(Diversity = factor(Diversity, levels = c("N0beta_add", "N0alpha"),
                            labels = c("beta", "alpha")),
         Dataset = "bryce")
divA <- rbind(divAvare, divAcatgrass, divAdune, 
              divAtrufe, divAvltava, divAbryce) %>% 
  mutate(Dataset = factor(Dataset, levels = c("vare", "catgrass", "dune",
                                              "trufe", "vltava", "bryce")),
         Method = "Sparse species removal")

div <- rbind(divF, divA)

ggplot(div, aes(Fminr, N0, fill = Diversity)) +
  geom_area() +
  labs(x = "Minimum species occupancy or abundance (%)",
       y = "Species richness") +
  facet_grid(rows = vars(Dataset), cols = vars(Method),
             scales = "free") +
  scale_fill_discrete(
    labels = expression(beta*N[0], bar(alpha*N[0]))) + 
  theme_bw()
ggsave("fig6.pdf", width = 7, height = 7)
ggsave("fig6.png", width = 7, height = 7)
ggsave("fig6.svg", width = 7, height = 7)



## Supplementary Figures with alpha, beta, gamma N1 and N2 ----

# Hill-Shannon diversity
divFvare <- varelistF$no %>% 
  mutate(N1beta_add = N1gamma - N1alpha) %>% 
  select(Fminr, N1alpha, N1beta_add) %>% 
  pivot_longer(-Fminr, names_to = "Diversity", values_to = "N1") %>% 
  mutate(Diversity = factor(Diversity, levels = c("N1beta_add", "N1alpha"),
                            labels = c("beta", "alpha")),
         Dataset = "vare")
divFcatgrass <- catgrasslistF$no %>% 
  mutate(N1beta_add = N1gamma - N1alpha) %>% 
  select(Fminr, N1alpha, N1beta_add) %>% 
  pivot_longer(-Fminr, names_to = "Diversity", values_to = "N1") %>% 
  mutate(Diversity = factor(Diversity, levels = c("N1beta_add", "N1alpha"),
                            labels = c("beta", "alpha")),
         Dataset = "catgrass")
divFdune <- dunelistF$no %>% 
  mutate(N1beta_add = N1gamma - N1alpha) %>% 
  select(Fminr, N1alpha, N1beta_add) %>% 
  pivot_longer(-Fminr, names_to = "Diversity", values_to = "N1") %>% 
  mutate(Diversity = factor(Diversity, levels = c("N1beta_add", "N1alpha"),
                            labels = c("beta", "alpha")),
         Dataset = "dune")
divFtrufe <- trufelistF$no %>% 
  mutate(N1beta_add = N1gamma - N1alpha) %>% 
  select(Fminr, N1alpha, N1beta_add) %>% 
  pivot_longer(-Fminr, names_to = "Diversity", values_to = "N1") %>% 
  mutate(Diversity = factor(Diversity, levels = c("N1beta_add", "N1alpha"),
                            labels = c("beta", "alpha")),
         Dataset = "trufe")
divFvltava <- vltavalistF$no %>% 
  mutate(N1beta_add = N1gamma - N1alpha) %>% 
  select(Fminr, N1alpha, N1beta_add) %>% 
  pivot_longer(-Fminr, names_to = "Diversity", values_to = "N1") %>% 
  mutate(Diversity = factor(Diversity, levels = c("N1beta_add", "N1alpha"),
                            labels = c("beta", "alpha")),
         Dataset = "vltava")
divFbryce <- brycelistF$no %>% 
  mutate(N1beta_add = N1gamma - N1alpha) %>% 
  select(Fminr, N1alpha, N1beta_add) %>% 
  pivot_longer(-Fminr, names_to = "Diversity", values_to = "N1") %>% 
  mutate(Diversity = factor(Diversity, levels = c("N1beta_add", "N1alpha"),
                            labels = c("beta", "alpha")),
         Dataset = "bryce")
divF <- rbind(divFvare, divFcatgrass, divFdune, 
              divFtrufe, divFvltava, divFbryce) %>% 
  mutate(Dataset = factor(Dataset, levels = c("vare", "catgrass", "dune",
                                              "trufe", "vltava", "bryce")),
         Method = "Rare species removal")

divAvare <- varelistA$no %>% 
  mutate(N1beta_add = N1gamma - N1alpha) %>% 
  select(Fminr, N1alpha, N1beta_add) %>% 
  pivot_longer(-Fminr, names_to = "Diversity", values_to = "N1") %>% 
  mutate(Diversity = factor(Diversity, levels = c("N1beta_add", "N1alpha"),
                            labels = c("beta", "alpha")),
         Dataset = "vare")
divAcatgrass <- catgrasslistA$no %>% 
  mutate(N1beta_add = N1gamma - N1alpha) %>% 
  select(Fminr, N1alpha, N1beta_add) %>% 
  pivot_longer(-Fminr, names_to = "Diversity", values_to = "N1") %>% 
  mutate(Diversity = factor(Diversity, levels = c("N1beta_add", "N1alpha"),
                            labels = c("beta", "alpha")),
         Dataset = "catgrass")
divAdune <- dunelistA$no %>% 
  mutate(N1beta_add = N1gamma - N1alpha) %>% 
  select(Fminr, N1alpha, N1beta_add) %>% 
  pivot_longer(-Fminr, names_to = "Diversity", values_to = "N1") %>% 
  mutate(Diversity = factor(Diversity, levels = c("N1beta_add", "N1alpha"),
                            labels = c("beta", "alpha")),
         Dataset = "dune")
divAtrufe <- trufelistA$no %>% 
  mutate(N1beta_add = N1gamma - N1alpha) %>% 
  select(Fminr, N1alpha, N1beta_add) %>% 
  pivot_longer(-Fminr, names_to = "Diversity", values_to = "N1") %>% 
  mutate(Diversity = factor(Diversity, levels = c("N1beta_add", "N1alpha"),
                            labels = c("beta", "alpha")),
         Dataset = "trufe")
divAvltava <- vltavalistA$no %>% 
  mutate(N1beta_add = N1gamma - N1alpha) %>% 
  select(Fminr, N1alpha, N1beta_add) %>% 
  pivot_longer(-Fminr, names_to = "Diversity", values_to = "N1") %>% 
  mutate(Diversity = factor(Diversity, levels = c("N1beta_add", "N1alpha"),
                            labels = c("beta", "alpha")),
         Dataset = "vltava")
divAbryce <- brycelistA$no %>% 
  mutate(N1beta_add = N1gamma - N1alpha) %>% 
  select(Fminr, N1alpha, N1beta_add) %>% 
  pivot_longer(-Fminr, names_to = "Diversity", values_to = "N1") %>% 
  mutate(Diversity = factor(Diversity, levels = c("N1beta_add", "N1alpha"),
                            labels = c("beta", "alpha")),
         Dataset = "bryce")
divA <- rbind(divAvare, divAcatgrass, divAdune, 
              divAtrufe, divAvltava, divAbryce) %>% 
  mutate(Dataset = factor(Dataset, levels = c("vare", "catgrass", "dune",
                                              "trufe", "vltava", "bryce")),
         Method = "Sparse species removal")

div <- rbind(divF, divA)

ggplot(div, aes(Fminr, N1, fill = Diversity)) +
  geom_area() +
  labs(x = "Minimum species occupancy or abundance (%)",
       y = "Hill-Shannon diversity") +
  facet_grid(rows = vars(Dataset), cols = vars(Method),
             scales = "free") +
  scale_fill_discrete(
    labels = expression(beta*N[1], bar(alpha*N[1]))) + 
  theme_bw()
ggsave("fig6N1.pdf", width = 7, height = 7)
ggsave("fig6N1.png", width = 7, height = 7)
ggsave("fig6N1.svg", width = 7, height = 7)

# Hill-Simpson diversity
divFvare <- varelistF$no %>% 
  mutate(N2beta_add = N2gamma - N2alpha) %>% 
  select(Fminr, N2alpha, N2beta_add) %>% 
  pivot_longer(-Fminr, names_to = "Diversity", values_to = "N2") %>% 
  mutate(Diversity = factor(Diversity, levels = c("N2beta_add", "N2alpha"),
                            labels = c("beta", "alpha")),
         Dataset = "vare")
divFcatgrass <- catgrasslistF$no %>% 
  mutate(N2beta_add = N2gamma - N2alpha) %>% 
  select(Fminr, N2alpha, N2beta_add) %>% 
  pivot_longer(-Fminr, names_to = "Diversity", values_to = "N2") %>% 
  mutate(Diversity = factor(Diversity, levels = c("N2beta_add", "N2alpha"),
                            labels = c("beta", "alpha")),
         Dataset = "catgrass")
divFdune <- dunelistF$no %>% 
  mutate(N2beta_add = N2gamma - N2alpha) %>% 
  select(Fminr, N2alpha, N2beta_add) %>% 
  pivot_longer(-Fminr, names_to = "Diversity", values_to = "N2") %>% 
  mutate(Diversity = factor(Diversity, levels = c("N2beta_add", "N2alpha"),
                            labels = c("beta", "alpha")),
         Dataset = "dune")
divFtrufe <- trufelistF$no %>% 
  mutate(N2beta_add = N2gamma - N2alpha) %>% 
  select(Fminr, N2alpha, N2beta_add) %>% 
  pivot_longer(-Fminr, names_to = "Diversity", values_to = "N2") %>% 
  mutate(Diversity = factor(Diversity, levels = c("N2beta_add", "N2alpha"),
                            labels = c("beta", "alpha")),
         Dataset = "trufe")
divFvltava <- vltavalistF$no %>% 
  mutate(N2beta_add = N2gamma - N2alpha) %>% 
  select(Fminr, N2alpha, N2beta_add) %>% 
  pivot_longer(-Fminr, names_to = "Diversity", values_to = "N2") %>% 
  mutate(Diversity = factor(Diversity, levels = c("N2beta_add", "N2alpha"),
                            labels = c("beta", "alpha")),
         Dataset = "vltava")
divFbryce <- brycelistF$no %>% 
  mutate(N2beta_add = N2gamma - N2alpha) %>% 
  select(Fminr, N2alpha, N2beta_add) %>% 
  pivot_longer(-Fminr, names_to = "Diversity", values_to = "N2") %>% 
  mutate(Diversity = factor(Diversity, levels = c("N2beta_add", "N2alpha"),
                            labels = c("beta", "alpha")),
         Dataset = "bryce")
divF <- rbind(divFvare, divFcatgrass, divFdune, 
              divFtrufe, divFvltava, divFbryce) %>% 
  mutate(Dataset = factor(Dataset, levels = c("vare", "catgrass", "dune",
                                              "trufe", "vltava", "bryce")),
         Method = "Rare species removal")

divAvare <- varelistA$no %>% 
  mutate(N2beta_add = N2gamma - N2alpha) %>% 
  select(Fminr, N2alpha, N2beta_add) %>% 
  pivot_longer(-Fminr, names_to = "Diversity", values_to = "N2") %>% 
  mutate(Diversity = factor(Diversity, levels = c("N2beta_add", "N2alpha"),
                            labels = c("beta", "alpha")),
         Dataset = "vare")
divAcatgrass <- catgrasslistA$no %>% 
  mutate(N2beta_add = N2gamma - N2alpha) %>% 
  select(Fminr, N2alpha, N2beta_add) %>% 
  pivot_longer(-Fminr, names_to = "Diversity", values_to = "N2") %>% 
  mutate(Diversity = factor(Diversity, levels = c("N2beta_add", "N2alpha"),
                            labels = c("beta", "alpha")),
         Dataset = "catgrass")
divAdune <- dunelistA$no %>% 
  mutate(N2beta_add = N2gamma - N2alpha) %>% 
  select(Fminr, N2alpha, N2beta_add) %>% 
  pivot_longer(-Fminr, names_to = "Diversity", values_to = "N2") %>% 
  mutate(Diversity = factor(Diversity, levels = c("N2beta_add", "N2alpha"),
                            labels = c("beta", "alpha")),
         Dataset = "dune")
divAtrufe <- trufelistA$no %>% 
  mutate(N2beta_add = N2gamma - N2alpha) %>% 
  select(Fminr, N2alpha, N2beta_add) %>% 
  pivot_longer(-Fminr, names_to = "Diversity", values_to = "N2") %>% 
  mutate(Diversity = factor(Diversity, levels = c("N2beta_add", "N2alpha"),
                            labels = c("beta", "alpha")),
         Dataset = "trufe")
divAvltava <- vltavalistA$no %>% 
  mutate(N2beta_add = N2gamma - N2alpha) %>% 
  select(Fminr, N2alpha, N2beta_add) %>% 
  pivot_longer(-Fminr, names_to = "Diversity", values_to = "N2") %>% 
  mutate(Diversity = factor(Diversity, levels = c("N2beta_add", "N2alpha"),
                            labels = c("beta", "alpha")),
         Dataset = "vltava")
divAbryce <- brycelistA$no %>% 
  mutate(N2beta_add = N2gamma - N2alpha) %>% 
  select(Fminr, N2alpha, N2beta_add) %>% 
  pivot_longer(-Fminr, names_to = "Diversity", values_to = "N2") %>% 
  mutate(Diversity = factor(Diversity, levels = c("N2beta_add", "N2alpha"),
                            labels = c("beta", "alpha")),
         Dataset = "bryce")
divA <- rbind(divAvare, divAcatgrass, divAdune, 
              divAtrufe, divAvltava, divAbryce) %>% 
  mutate(Dataset = factor(Dataset, levels = c("vare", "catgrass", "dune",
                                              "trufe", "vltava", "bryce")),
         Method = "Sparse species removal")

div <- rbind(divF, divA)

ggplot(div, aes(Fminr, N2, fill = Diversity)) +
  geom_area() +
  labs(x = "Minimum species occupancy or abundance (%)",
       y = "Hill-Simpson diversity") +
  facet_grid(rows = vars(Dataset), cols = vars(Method),
             scales = "free") +
  scale_fill_discrete(
    labels = expression(beta*N[2], bar(alpha*N[2]))) + 
  theme_bw()
ggsave("fig6N2.pdf", width = 7, height = 7)
ggsave("fig6N2.png", width = 7, height = 7)
ggsave("fig6N2.svg", width = 7, height = 7)



## Fig. 7 - Multiplicative beta diversity ----

bdivFvare <- varelistF$no %>% 
  select(Fminr, N0beta, N1beta, N2beta) %>% 
  pivot_longer(-Fminr, names_to = "Diversity", values_to = "betaTD") %>% 
  mutate(Diversity = factor(Diversity, 
                            levels = c("N0beta", "N1beta", "N2beta"),
                            labels = c("N0", "N1","N2")),
         Dataset = "vare")
bdivFcatgrass <- catgrasslistF$no %>% 
  select(Fminr, N0beta, N1beta, N2beta) %>% 
  pivot_longer(-Fminr, names_to = "Diversity", values_to = "betaTD") %>% 
  mutate(Diversity = factor(Diversity, 
                            levels = c("N0beta", "N1beta", "N2beta"),
                            labels = c("N0", "N1","N2")),
         Dataset = "catgrass")
bdivFdune <- dunelistF$no %>% 
  select(Fminr, N0beta, N1beta, N2beta) %>% 
  pivot_longer(-Fminr, names_to = "Diversity", values_to = "betaTD") %>% 
  mutate(Diversity = factor(Diversity, 
                            levels = c("N0beta", "N1beta", "N2beta"),
                            labels = c("N0", "N1","N2")),
         Dataset = "dune")
bdivFtrufe <- trufelistF$no %>% 
  select(Fminr, N0beta, N1beta, N2beta) %>% 
  pivot_longer(-Fminr, names_to = "Diversity", values_to = "betaTD") %>% 
  mutate(Diversity = factor(Diversity, 
                            levels = c("N0beta", "N1beta", "N2beta"),
                            labels = c("N0", "N1","N2")),
         Dataset = "trufe")
bdivFvltava <- vltavalistF$no %>% 
  select(Fminr, N0beta, N1beta, N2beta) %>% 
  pivot_longer(-Fminr, names_to = "Diversity", values_to = "betaTD") %>% 
  mutate(Diversity = factor(Diversity, 
                            levels = c("N0beta", "N1beta", "N2beta"),
                            labels = c("N0", "N1","N2")),
         Dataset = "vltava")
bdivFbryce <- brycelistF$no %>% 
  select(Fminr, N0beta, N1beta, N2beta) %>% 
  pivot_longer(-Fminr, names_to = "Diversity", values_to = "betaTD") %>% 
  mutate(Diversity = factor(Diversity, 
                            levels = c("N0beta", "N1beta", "N2beta"),
                            labels = c("N0", "N1","N2")),
         Dataset = "bryce")
bdivF <- rbind(bdivFvare, bdivFcatgrass, bdivFdune, 
              bdivFtrufe, bdivFvltava, bdivFbryce) %>% 
  mutate(Dataset = factor(Dataset, levels = c("vare", "catgrass", "dune",
                                              "trufe", "vltava", "bryce")),
         Method = "Rare species removal")

# ggplot(bdivF, aes(Fminr, betaTD, colour = Diversity)) +
#   geom_line() +
#   labs(x = "Minimum species frequency (%)",
#        y = "Multiplicative beta taxonomic diversity",
#        title = "Rare species exclusion") +
#   facet_wrap(vars(Dataset), nrow = 3, ncol = 3, scales = "free") +
#   theme_bw()


bdivAvare <- varelistA$no %>% 
  select(Fminr, N0beta, N1beta, N2beta) %>% 
  pivot_longer(-Fminr, names_to = "Diversity", values_to = "betaTD") %>% 
  mutate(Diversity = factor(Diversity, 
                            levels = c("N0beta", "N1beta", "N2beta"),
                            labels = c("N0", "N1","N2")),
         Dataset = "vare")
bdivAcatgrass <- catgrasslistA$no %>% 
  select(Fminr, N0beta, N1beta, N2beta) %>% 
  pivot_longer(-Fminr, names_to = "Diversity", values_to = "betaTD") %>% 
  mutate(Diversity = factor(Diversity, 
                            levels = c("N0beta", "N1beta", "N2beta"),
                            labels = c("N0", "N1","N2")),
         Dataset = "catgrass")
bdivAdune <- dunelistA$no %>% 
  select(Fminr, N0beta, N1beta, N2beta) %>% 
  pivot_longer(-Fminr, names_to = "Diversity", values_to = "betaTD") %>% 
  mutate(Diversity = factor(Diversity, 
                            levels = c("N0beta", "N1beta", "N2beta"),
                            labels = c("N0", "N1","N2")),
         Dataset = "dune")
bdivAtrufe <- trufelistA$no %>% 
  select(Fminr, N0beta, N1beta, N2beta) %>% 
  pivot_longer(-Fminr, names_to = "Diversity", values_to = "betaTD") %>% 
  mutate(Diversity = factor(Diversity, 
                            levels = c("N0beta", "N1beta", "N2beta"),
                            labels = c("N0", "N1","N2")),
         Dataset = "trufe")
bdivAvltava <- vltavalistA$no %>% 
  select(Fminr, N0beta, N1beta, N2beta) %>% 
  pivot_longer(-Fminr, names_to = "Diversity", values_to = "betaTD") %>% 
  mutate(Diversity = factor(Diversity, 
                            levels = c("N0beta", "N1beta", "N2beta"),
                            labels = c("N0", "N1","N2")),
         Dataset = "vltava")
bdivAbryce <- brycelistA$no %>% 
  select(Fminr, N0beta, N1beta, N2beta) %>% 
  pivot_longer(-Fminr, names_to = "Diversity", values_to = "betaTD") %>% 
  mutate(Diversity = factor(Diversity, 
                            levels = c("N0beta", "N1beta", "N2beta"),
                            labels = c("N0", "N1","N2")),
         Dataset = "bryce")
bdivA <- rbind(bdivAvare, bdivAcatgrass, bdivAdune, 
               bdivAtrufe, bdivAvltava, bdivAbryce) %>% 
  mutate(Dataset = factor(Dataset, levels = c("vare", "catgrass", "dune",
                                              "trufe", "vltava", "bryce")),
         Method = "Sparse species removal")

# ggplot(bdivA, aes(Fminr, betaTD, colour = Diversity)) +
#   geom_line() +
#   labs(x = "Minimum relative species cover (%)",
#        y = "Multiplicative beta taxonomic diversity",
#        title = "Sparse species exclusion") +
#   facet_wrap(vars(Dataset), nrow = 3, ncol = 3, scales = "free") +
#   theme_bw()

bdiv <- rbind(bdivF, bdivA)
# bdiv <- rbind(bdivF, bdivA[bdivA$Fminr < 25, ])

ggplot(bdiv, aes(Fminr, betaTD, colour = Diversity)) +
  geom_line(linewidth = 0.6, alpha = 0.6) +
  geom_point(size = 1, 
             shape = 21,
             fill = "white") +
  labs(x = "Minimum species occupancy or abundance (%)",
       y = "Multiplicative beta taxonomic diversity") +
  facet_grid(rows = vars(Dataset), cols = vars(Method),
             scales = "free") +
  scale_colour_discrete(
    # name = "Beta diversity", 
    labels = expression(beta*N[0], beta*N[1], beta*N[2])) + 
  theme_bw()
ggsave("fig7.pdf", width = 8, height = 7)
ggsave("fig7.png", width = 8, height = 7)
ggsave("fig7.svg", width = 8, height = 7)



# Constrained ordination ----

## Fig. 8 - RDA results (variation explained) ----

# maxocc <- 50
# maxabu <- 25
maxocc <- 80
maxabu <- 100

pv1 <- extractR2(varelistF) %>% 
  mutate(Dataset = "vare", 
         Method = "Rare species removal") %>%
  filter(Fminr <= maxocc)
pv2 <- extractR2(varelistA) %>% 
  mutate(Dataset = "vare", 
         Method = "Sparse species removal") %>%
  filter(Fminr <= maxabu)
pc1 <- extractR2(catgrasslistF) %>% 
  mutate(Dataset = "catgrass", 
         Method = "Rare species removal") %>%
  filter(Fminr <= maxocc)
pc2 <- extractR2(catgrasslistA) %>% 
  mutate(Dataset = "catgrass", 
         Method = "Sparse species removal") %>%
  filter(Fminr <= maxabu)
pd1 <- extractR2(dunelistF) %>% 
  mutate(Dataset = "dune", 
         Method = "Rare species removal") %>%
  filter(Fminr <= maxocc)
pd2 <- extractR2(dunelistA) %>% 
  mutate(Dataset = "dune", 
         Method = "Sparse species removal") %>%
  filter(Fminr <= maxabu)
pt1 <- extractR2(trufelistF) %>% 
  mutate(Dataset = "trufe", 
         Method = "Rare species removal") %>%
  filter(Fminr <= maxocc)
pt2 <- extractR2(trufelistA) %>% 
  mutate(Dataset = "trufe", 
         Method = "Sparse species removal") %>%
  filter(Fminr <= maxabu)
pa1 <- extractR2(vltavalistF) %>% 
  mutate(Dataset = "vltava", 
         Method = "Rare species removal") %>%
  filter(Fminr <= maxocc)
pa2 <- extractR2(vltavalistA) %>% 
  mutate(Dataset = "vltava", 
         Method = "Sparse species removal") %>%
  filter(Fminr <= maxabu)
pb1 <- extractR2(brycelistF) %>% 
  mutate(Dataset = "bryce", 
         Method = "Rare species removal") %>%
  filter(Fminr <= maxocc)
pb2 <- extractR2(brycelistA) %>% 
  mutate(Dataset = "bryce", 
         Method = "Sparse species removal") %>%
  filter(Fminr <= maxabu)

R2s <- rbind(pv1, pv2, pc1, pc2, pd1, pd2, pt1, pt2, pa1, pa2, pb1, pb2) %>% 
  mutate(Dataset = factor(Dataset, 
                          levels = c("vare", "catgrass", "dune",
                                     "trufe", "vltava", "bryce")))

ggplot(R2s, aes(Fminr, 100 * adjR2, colour = Data)) +
  geom_line(alpha = 0.6) +
  geom_point(size = 0.75, fill = "white", aes(shape = pp)) +
  scale_shape_identity() +
  labs(x = "Minimum occupancy or abundance (%)", 
       y = "Explained variation (%)") +
  scale_color_manual(values = c(1, 4, 2, 3, "orange")) +
  # scale_x_continuous(breaks = seq(0, 100, by = 10)) +
  facet_grid(rows = vars(Dataset), 
             cols = vars(Method), 
             scales = "free") +
  theme_bw()
ggsave("fig8.pdf", width = 7, height = 7)
ggsave("fig8.png", width = 7, height = 7)
ggsave("fig8.svg", width = 7, height = 7)


## Fig. 9 - RDA results (contribution of axis 1) ----

pv3 <- extractAx1(varelistF) %>% 
  mutate(Dataset = "vare", 
         Method = "Rare species removal") %>%
  filter(Fminr <= maxocc)
pv4 <- extractAx1(varelistA) %>% 
  mutate(Dataset = "vare", 
         Method = "Sparse species removal") %>%
  filter(Fminr <= maxabu)
pc3 <- extractAx1(catgrasslistF) %>% 
  mutate(Dataset = "catgrass", 
         Method = "Rare species removal") %>%
  filter(Fminr <= maxocc)
pc4 <- extractAx1(catgrasslistA) %>% 
  mutate(Dataset = "catgrass", 
         Method = "Sparse species removal") %>%
  filter(Fminr <= maxabu)
pd3 <- extractAx1(dunelistF) %>% 
  mutate(Dataset = "dune", 
         Method = "Rare species removal") %>%
  filter(Fminr <= maxocc)
pd4 <- extractAx1(dunelistA) %>% 
  mutate(Dataset = "dune", 
         Method = "Sparse species removal") %>%
  filter(Fminr <= maxabu)
pt3 <- extractAx1(trufelistF) %>% 
  mutate(Dataset = "trufe", 
         Method = "Rare species removal") %>%
  filter(Fminr <= maxocc)
pt4 <- extractAx1(trufelistA) %>% 
  mutate(Dataset = "trufe", 
         Method = "Sparse species removal") %>%
  filter(Fminr <= maxabu)
pa3 <- extractAx1(vltavalistF) %>% 
  mutate(Dataset = "vltava", 
         Method = "Rare species removal") %>%
  filter(Fminr <= maxocc)
pa4 <- extractAx1(vltavalistA) %>% 
  mutate(Dataset = "vltava", 
         Method = "Sparse species removal") %>%
  filter(Fminr <= maxabu)
pb3 <- extractAx1(brycelistF) %>% 
  mutate(Dataset = "bryce", 
         Method = "Rare species removal") %>%
  filter(Fminr <= maxocc)
pb4 <- extractAx1(brycelistA) %>% 
  mutate(Dataset = "bryce", 
         Method = "Sparse species removal") %>%
  filter(Fminr <= maxabu)

Ax1s <- rbind(pv3, pv4, pc3, pc4, pd3, pd4, pt3, pt4, pa3, pa4, pb3, pb4) %>% 
  mutate(Dataset = factor(Dataset, 
                          levels = c("vare", "catgrass", "dune",
                                     "trufe", "vltava", "bryce")))

ggplot(Ax1s, aes(Fminr, RDA1, colour = Data)) +
  geom_line(alpha = 0.6) +
  geom_point(size = 0.75, fill = "white", aes(shape = pp)) +
  scale_shape_identity() +
  labs(x = "Minimum occupancy or abundance (%)", 
       y = "Contribution of RDA axis 1 (%)") +
  scale_color_manual(values = c(1, 4, 2, 3, "orange")) +
  facet_grid(rows = vars(Dataset), 
             cols = vars(Method), 
             scales = "free") +
  theme_bw()
ggsave("fig9.pdf", width = 7, height = 7)
ggsave("fig9.png", width = 7, height = 7)
ggsave("fig9.svg", width = 7, height = 7)

