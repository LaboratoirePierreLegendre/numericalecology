#
### Fichier d'analyse pour la publication du l'article sur l'extension multi-réponse de la MCA.
### Analysis files for the mMCA paper
### Utilise une version >0.6-4 de codep
### Uses codep v>0.6-4
### Guillaume Guénard, Université de Montréal - septembre 2015 - février 2017
#
### Pour remettre la liste de processus actifs à 0, envoyer la requête suivante:
### To reset the simulation processes, send the following query:
### dbSendQuery(con1,"UPDATE MCASims.Simulations SET PID=null")
### dbSendQuery(con1,"UPDATE MCASims.Simulations SET PID=null WHERE PID=28339")
# rm(list=ls())
#
source("MS15 - MultiMCA - Aux.R")
### Initialisation du simulateur - Initialize the simulator
init()
#
Conditions <- fetch(dbSendQuery(con1,"SELECT Test, Nsites as N, Nspecies as M FROM MCASims.Simulations
                                      GROUP BY Test, Nsites, Nspecies ORDER BY Nsites, Nspecies, Test;"),n=-1)
alpha <- c(0.005,0.01,0.05,0.1,0.5,0.9) ; alphaTypeII <- 0.05
RejRates <- data.frame(Conditions[,0L],matrix(NA,nrow(Conditions),3L*length(alpha)))
colnames(RejRates) <- paste(rep(c("UB","fit","LB"),length(alpha)),rep(alpha,each=3L),sep="_")
typeIIcurves <- list()
PowerThresholds <- data.frame(Conditions[,0L],matrix(NA,nrow(Conditions),9L,
                              dimnames=list(NULL,paste("Det",c(0.01,0.05,0.1,0.25,0.5,0.75,0.9,0.95,0.99),sep="_"))))
for(i in 1L:nrow(Conditions)) {
  # i <- 1L
  tmp <- fetch(dbSendQuery(con1,sprintf("SELECT MCASims.Results.typeI as typeI, log10(MCASims.Results.snr) AS log10snr, (MCASims.Results.typeII < %f) AS detected
                                  FROM MCASims.Simulations JOIN MCASims.Results ON MCASims.Simulations.SimID = MCASims.Results.SimID
                                  WHERE Nsites = %d AND Nspecies = %d AND Test = '%s';",alphaTypeII,Conditions[i,"N"],Conditions[i,"M"],
                                  Conditions[i,"Test"])),n=-1)
  for(j in 1L:length(alpha)) {
    # j <- 1L
    glmtmp <- glm(as.numeric(typeI<alpha[j])~1,data=tmp,family=binomial())
    prdglm <- predict(glmtmp,newdata=data.frame(matrix(NA,1L,0L)),se.fit=TRUE)
    RejRates[i,3L*(j-1L)+(1L:3L)] <- binomial()$linkinv(prdglm$fit + prdglm$se.fit * qt(p = 0.995, df = nrow(tmp)-1) * c(-1,0,1))
  }
  #
  glmtmp <- glm(detected~log10snr,data=tmp,family=binomial())
  prdglm <- predict(glmtmp,newdata=data.frame(log10snr=seq(-3,2,length.out=1000L)),se.fit=TRUE)
  typeIIcurves[[i]] <- list(LB95=binomial()$linkinv(prdglm$fit+qt(0.025,glmtmp$df.residual)*prdglm$se.fit),
                            MEAN=binomial()$linkinv(prdglm$fit),
                            UB95=binomial()$linkinv(prdglm$fit+qt(0.975,glmtmp$df.residual)*prdglm$se.fit))
  typeIIcurves[[i]]$b <- coef(glmtmp)
  plot(NA,xlim=c(-2.3,1.5),ylim=c(0,1),axes=FALSE,ylab="Statistical power",xlab="snr")
  axis(1,label=c("1:1000","1:100","1:10","1:1","10:1","100:1"),at=-3:2)
  axis(2,las=1)
  lines(y=typeIIcurves[[i]]$MEAN,x=seq(-3,2,length.out=1000L),lwd=2)
  abline(v=((-log(1/c(0.01,0.05,0.1,0.25,0.5,0.75,0.9,0.95,0.99)-1)-typeIIcurves[[i]]$b[1L])/typeIIcurves[[i]]$b[2L]),lty=3L)
  abline(h=c(0.01,0.05,0.1,0.25,0.5,0.75,0.9,0.95,0.99),lty=3L)
  PowerThresholds[i,] <- 10^((-log(1/c(0.01,0.05,0.1,0.25,0.5,0.75,0.9,0.95,0.99)-1)-typeIIcurves[[i]]$b[1L])/typeIIcurves[[i]]$b[2L])   # Calculs vérifié 11 mars 2016
} ; rm(i,tmp,j,glmtmp,prdglm)
#
plot(NA,xlim=c(-3,1.5),ylim=c(0,1),axes=FALSE,ylab="Statistical power",xlab="snr")
axis(1,label=c("1:1000","1:100","1:10","1:1","10:1","100:1"),at=-3:2)
axis(2,las=1)
sel <- which(Conditions[,"Test"]=="parametric" & Conditions[,"M"]==1L)
for(i in sel) {
  # i <- sel[1L]
  lines(y=typeIIcurves[[i]]$MEAN,x=seq(-3,2,length.out=1000L),lwd=2)
  lines(y=typeIIcurves[[i]]$LB95,x=seq(-3,2,length.out=1000L),lty=3L,lwd=2)
  lines(y=typeIIcurves[[i]]$UB95,x=seq(-3,2,length.out=1000L),lty=3L,lwd=2)
}
abline(h=0.95,lty=3L)
#
logit <- function(x) -log(1/x-1)
x <- c(0.002,0.005,0.01,0.02,0.05,0.1,0.2,0.5,0.8,0.9,0.95) ; m <- c(0L:2,15L:17)
X11(height=4, width=7.25) ; par(mar=c(4.5,6.75,1,1))
N <- unique(Conditions[Conditions[,"Test"]=="parametric","N"])
plot(NA,ylim=logit(c(0.002,0.95)),xlim=c(0.5,7.5),axes=FALSE,ylab="Significance level\n\n",xlab="")
axis(1L,label=Conditions[Conditions[,"Test"]=="parametric","M"],
     at=rep(1L:length(N),each=4L)+rep(seq(-0.3,0.3,0.2),length(N)),las=3,cex.axis=0.9)
axis(2L,label=x,at=logit(x),las=1L)
box()
mtext(side=1L,text=paste("",N,sep=""),at=1L:length(N),line=2.5,font=2)
mtext(side=1L,outer=TRUE,text=paste("Number of",c("species","sites")),at=0.02,line=c(-3.8,-2.05),cex=1,adj=0)
abline(h=logit(alpha),lty=3L)
for(j in 1L:length(alpha)) {
  # j <- 1L
  points(y=logit(RejRates[Conditions[,"Test"]=="parametric",3L*(j-1L)+2L]),x=rep(1L:length(N),each=4L)+rep(seq(-0.3,0.3,0.2),length(N)),pch=m[j],bg="black")
  arrows(y0=logit(RejRates[Conditions[,"Test"]=="parametric",3L*(j-1L)+1L]),y1=logit(RejRates[Conditions[,"Test"]=="parametric",3L*(j-1L)+3L]),
         x0=rep(1L:length(N),each=4L)+rep(seq(-0.3,0.3,0.2),length(N)),x1=rep(1L:length(N),each=4L)+rep(seq(-0.3,0.3,0.2),length(N)),
         code=3L,angle=90,length=0.05)
} ; rm(x,N,j)
## dev.copy2eps(file="./Images/Type I error rate - parametric.eps") ; dev.off()
#
X11(height=4, width=4.75) ; par(mar=c(4.5,6.75,1,1))
x <- c(0.002,0.005,0.01,0.02,0.05,0.1,0.2,0.5,0.8,0.9,0.95)
N <- unique(Conditions[Conditions[,"Test"]=="permutations","N"])
plot(NA,ylim=logit(c(0.002,0.95)),xlim=c(0.5,4.5),axes=FALSE,ylab="Significance level\n\n",xlab="")
axis(1L,label=Conditions[Conditions[,"Test"]=="permutations","M"],
     at=rep(1L:length(N),each=4L)+rep(seq(-0.3,0.3,0.2),length(N)),las=3,cex.axis=0.9)
axis(2L,label=x,at=logit(x),las=1L)
box()
mtext(side=1L,text=paste("",N,sep=""),at=1L:length(N),line=2.5,font=2)
mtext(side=1L,outer=TRUE,text=paste("Number of",c("species","sites")),at=0.02,line=c(-3.8,-2.05),cex=1,adj=0)
abline(h=logit(alpha),lty=3L)
for(j in 1L:length(alpha)) {
  # j <- 1L
  points(y=logit(RejRates[Conditions[,"Test"]=="permutations",3L*(j-1L)+2L]),x=rep(1L:length(N),each=4L)+rep(seq(-0.3,0.3,0.2),length(N)),pch=m[j],bg="black")
  arrows(y0=logit(RejRates[Conditions[,"Test"]=="permutations",3L*(j-1L)+1L]),y1=logit(RejRates[Conditions[,"Test"]=="permutations",3L*(j-1L)+3L]),
         x0=rep(1L:length(N),each=4L)+rep(seq(-0.3,0.3,0.2),length(N)),x1=rep(1L:length(N),each=4L)+rep(seq(-0.3,0.3,0.2),length(N)),
         code=3L,angle=90,length=0.05)
} ; rm(N,j)
## dev.copy2eps(file="./Images/Type I error rate - permutations.eps") ; dev.off()
#
# N <- unique(Conditions[Conditions[,"Test"]=="parametric","N"])
# PowerThresholds[Conditions[,"Test"]=="parametric",]
# PowerThresholds[Conditions[,"Test"]=="permutations",]
#
### Afficher les courbes sur une échelle logit.
X11(width=7.25,height=8.5)
x <- c(0.001,0.002,0.005,0.01,0.02,0.05,0.1,0.25,0.5,0.75,0.9,0.95,0.98,0.99,0.995,0.998,0.999)
lty <- c("1242","121242","12121242","1282","121282","12121282","12B2")
par(mar=c(2.5,6,2.5,0),fig=c(0,0.5,0.5,1))
plot(NA,xlim=c(-2.5,1.5),ylim=logit(c(0.001,0.999)),axes=FALSE,ylab="",xlab="")
axis(1,label=c("1:100","1:10","1:1","10:1","100:1"),at=-2:2)
axis(2,label=x,at=logit(x),las=1)
sel <- which(Conditions[,"Test"]=="parametric" & Conditions[,"M"]==1L)
for(i in 1L:length(sel))
  lines(y=logit(typeIIcurves[[sel[i]]]$MEAN),x=seq(-3,2,length.out=1000L),lwd=2,lty=lty[i])
abline(h=logit(0.95),lty=3L) ; box() ; text("A",x=-2.4,y=logit(0.9985),font=2,cex=1.25)
legend(x=-0.45,y=-1,legend=paste(Conditions[sel,"N"],", ",Conditions[sel,"M"],sep=""),lty=lty,
       lwd=2,cex=0.85)
#
par(mar=c(2.5,4,2.5,2),fig=c(0.5,1,0.5,1),new=TRUE)
plot(NA,xlim=c(-2.5,1.5),ylim=logit(c(0.001,0.999)),axes=FALSE,ylab="",xlab="")
axis(1,label=c("1:100","1:10","1:1","10:1","100:1"),at=-2:2)
axis(2,label=x,at=logit(x),las=1)
sel <- which(Conditions[,"Test"]=="parametric" & (Conditions[,"M"]==2L | (Conditions[,"N"]==25L & Conditions[,"M"]==3L) | (Conditions[,"N"]==50L & Conditions[,"M"]==5L) |
                                                  (Conditions[,"N"]==100L & Conditions[,"M"]==10L) | (Conditions[,"N"]==250L & Conditions[,"M"]==20L) | (Conditions[,"N"]==500L & Conditions[,"M"]==50L) |
                                                  (Conditions[,"N"]==1000L & Conditions[,"M"]==100L)))
for(i in 1L:length(sel))
  lines(y=logit(typeIIcurves[[sel[i]]]$MEAN),x=seq(-3,2,length.out=1000L),lwd=2,lty=lty[i])
abline(h=logit(0.95),lty=3L) ; box() ; text("B",x=-2.4,y=logit(0.9985),font=2,cex=1.25)
legend(x=-0.65,y=-1,legend=paste(Conditions[sel,"N"],", ",Conditions[sel,"M"],sep=""),lty=lty,
       lwd=2,cex=0.85)
#
par(mar=c(4,6,1,0),fig=c(0,0.5,0,0.5),new=TRUE)
plot(NA,xlim=c(-2.5,1.5),ylim=logit(c(0.001,0.999)),axes=FALSE,ylab="",xlab="")
axis(1,label=c("1:100","1:10","1:1","10:1","100:1"),at=-2:2)
axis(2,label=x,at=logit(x),las=1)
sel <- which(Conditions[,"Test"]=="parametric" & ((Conditions[,"N"]==10L & Conditions[,"M"]==3L) | (Conditions[,"N"]==25L & Conditions[,"M"]==5L) | (Conditions[,"N"]==50L & Conditions[,"M"]==10L) |
                                                  (Conditions[,"N"]==100L & Conditions[,"M"]==20L) | (Conditions[,"N"]==250L & Conditions[,"M"]==50L) | (Conditions[,"N"]==500L & Conditions[,"M"]==100L) |
                                                  (Conditions[,"N"]==1000L & Conditions[,"M"]==250L)))
for(i in 1L:length(sel))
  lines(y=logit(typeIIcurves[[sel[i]]]$MEAN),x=seq(-3,2,length.out=1000L),lwd=2,lty=lty[i])
abline(h=logit(0.95),lty=3L) ; box() ; text("C",x=-2.4,y=logit(0.9985),font=2,cex=1.25)
legend(x=-0.65,y=-1,legend=paste(Conditions[sel,"N"],", ",Conditions[sel,"M"],sep=""),lty=lty,
       lwd=2,cex=0.85)
#
par(mar=c(4,4,1,2),fig=c(0.5,1,0,0.5),new=TRUE)
plot(NA,xlim=c(-2.5,1.5),ylim=logit(c(0.001,0.999)),axes=FALSE,ylab="",xlab="")
axis(1,label=c("1:100","1:10","1:1","10:1","100:1"),at=-2:2)
axis(2,label=x,at=logit(x),las=1)
sel <- which(Conditions[,"Test"]=="parametric" & ((Conditions[,"N"]==10L & Conditions[,"M"]==5L) | (Conditions[,"N"]==25L & Conditions[,"M"]==10L) | (Conditions[,"N"]==50L & Conditions[,"M"]==20L) |
                                                  (Conditions[,"N"]==100L & Conditions[,"M"]==50L) | (Conditions[,"N"]==250L & Conditions[,"M"]==100L) | (Conditions[,"N"]==500L & Conditions[,"M"]==250L) |
                                                  (Conditions[,"N"]==1000L & Conditions[,"M"]==500L)))
for(i in 1L:length(sel))
  lines(y=logit(typeIIcurves[[sel[i]]]$MEAN),x=seq(-3,2,length.out=1000L),lwd=2,lty=lty[i])
abline(h=logit(0.95),lty=3L) ; box() ; text("D",x=-2.4,y=logit(0.9985),font=2,cex=1.25)
legend(x=-0.65,y=-1,legend=paste(Conditions[sel,"N"],", ",Conditions[sel,"M"],sep=""),lty=lty,
       lwd=2,cex=0.85)
mtext("SNR",1L,-1.25,TRUE,0.55,cex=1.25)
mtext("Rejection rate",2L,-1.25,TRUE,0.525,cex=1.25)
rm(x,lty,sel,i)
#
## dev.copy2eps(file="./Images/Type II error rate - parametric.eps") ; dev.off()
X11(width=7.25,height=8.5)
x <- c(0.001,0.002,0.005,0.01,0.02,0.05,0.1,0.25,0.5,0.75,0.9,0.95,0.98,0.99,0.995,0.998,0.999)
lty <- c("1242","121242","12121242","1282")
par(mar=c(2.5,6,2.5,0),fig=c(0,0.5,0.5,1))
plot(NA,xlim=c(-2.5,1.5),ylim=logit(c(0.001,0.999)),axes=FALSE,ylab="",xlab="")
axis(1,label=c("1:100","1:10","1:1","10:1","100:1"),at=-2:2)
axis(2,label=x,at=logit(x),las=1)
sel <- which(Conditions[,"Test"]=="permutations" & Conditions[,"M"]==1L)
for(i in 1L:length(sel))
  lines(y=logit(typeIIcurves[[sel[i]]]$MEAN),x=seq(-3,2,length.out=1000L),lwd=2,lty=lty[i])
abline(h=logit(0.95),lty=3L) ; box() ; text("A",x=-2.4,y=logit(0.9985),font=2,cex=1.25)
legend(x=-0.85,y=-2.3,legend=paste(Conditions[sel,"N"],", ",Conditions[sel,"M"],sep=""),lty=lty,
       lwd=2,cex=0.85)
#
par(mar=c(2.5,4,2.5,2),fig=c(0.5,1,0.5,1),new=TRUE)
plot(NA,xlim=c(-2.5,1.5),ylim=logit(c(0.001,0.999)),axes=FALSE,ylab="",xlab="")
axis(1,label=c("1:100","1:10","1:1","10:1","100:1"),at=-2:2)
axis(2,label=x,at=logit(x),las=1)
sel <- which(Conditions[,"Test"]=="permutations" & (Conditions[,"M"]==2L | (Conditions[,"N"]==25L & Conditions[,"M"]==3L) | (Conditions[,"N"]==50L & Conditions[,"M"]==5L) |
                                                    (Conditions[,"N"]==100L & Conditions[,"M"]==10L) | (Conditions[,"N"]==250L & Conditions[,"M"]==20L) | (Conditions[,"N"]==500L & Conditions[,"M"]==50L) |
                                                    (Conditions[,"N"]==1000L & Conditions[,"M"]==100L)))
for(i in 1L:length(sel))
  lines(y=logit(typeIIcurves[[sel[i]]]$MEAN),x=seq(-3,2,length.out=1000L),lwd=2,lty=lty[i])
abline(h=logit(0.95),lty=3L) ; box() ; text("B",x=-2.4,y=logit(0.9985),font=2,cex=1.25)
legend(x=-0.85,y=-2.3,legend=paste(Conditions[sel,"N"],", ",Conditions[sel,"M"],sep=""),lty=lty,
       lwd=2,cex=0.85)
#
par(mar=c(4,6,1,0),fig=c(0,0.5,0,0.5),new=TRUE)
plot(NA,xlim=c(-2.5,1.5),ylim=logit(c(0.001,0.999)),axes=FALSE,ylab="",xlab="")
axis(1,label=c("1:100","1:10","1:1","10:1","100:1"),at=-2:2)
axis(2,label=x,at=logit(x),las=1)
sel <- which(Conditions[,"Test"]=="permutations" & ((Conditions[,"N"]==10L & Conditions[,"M"]==3L) | (Conditions[,"N"]==25L & Conditions[,"M"]==5L) | (Conditions[,"N"]==50L & Conditions[,"M"]==10L) |
                                                    (Conditions[,"N"]==100L & Conditions[,"M"]==20L) | (Conditions[,"N"]==250L & Conditions[,"M"]==50L) | (Conditions[,"N"]==500L & Conditions[,"M"]==100L) |
                                                    (Conditions[,"N"]==1000L & Conditions[,"M"]==250L)))
for(i in 1L:length(sel))
  lines(y=logit(typeIIcurves[[sel[i]]]$MEAN),x=seq(-3,2,length.out=1000L),lwd=2,lty=lty[i])
abline(h=logit(0.95),lty=3L) ; box() ; text("C",x=-2.4,y=logit(0.9985),font=2,cex=1.25)
legend(x=-0.85,y=-2.3,legend=paste(Conditions[sel,"N"],", ",Conditions[sel,"M"],sep=""),lty=lty,
       lwd=2,cex=0.85)
#
par(mar=c(4,4,1,2),fig=c(0.5,1,0,0.5),new=TRUE)
plot(NA,xlim=c(-2.5,1.5),ylim=logit(c(0.001,0.999)),axes=FALSE,ylab="",xlab="")
axis(1,label=c("1:100","1:10","1:1","10:1","100:1"),at=-2:2)
axis(2,label=x,at=logit(x),las=1)
sel <- which(Conditions[,"Test"]=="permutations" & ((Conditions[,"N"]==10L & Conditions[,"M"]==5L) | (Conditions[,"N"]==25L & Conditions[,"M"]==10L) | (Conditions[,"N"]==50L & Conditions[,"M"]==20L) |
                                                    (Conditions[,"N"]==100L & Conditions[,"M"]==50L) | (Conditions[,"N"]==250L & Conditions[,"M"]==100L) | (Conditions[,"N"]==500L & Conditions[,"M"]==250L) |
                                                    (Conditions[,"N"]==1000L & Conditions[,"M"]==500L)))
for(i in 1L:length(sel))
  lines(y=logit(typeIIcurves[[sel[i]]]$MEAN),x=seq(-3,2,length.out=1000L),lwd=2,lty=lty[i])
abline(h=logit(0.95),lty=3L) ; box() ; text("D",x=-2.4,y=logit(0.9985),font=2,cex=1.25)
legend(x=-0.85,y=-2.3,legend=paste(Conditions[sel,"N"],", ",Conditions[sel,"M"],sep=""),lty=lty,
       lwd=2,cex=0.85)
mtext("SNR",1L,-1.25,TRUE,0.55,cex=1.25)
mtext("Rejection rate",2L,-1.25,TRUE,0.525,cex=1.25)
rm(x,lty,sel,i)
## dev.copy2eps(file="./Images/Type II error rate - permutations.eps") ; dev.off()
#
test <- as.factor(Conditions[,"Test"])
X <- as.matrix(cbind(1,test=contr.treatment(n=nlevels(test),base=1L)[test],N=Conditions[,"N"],M=Conditions["M"]))
rm(test)
Z <- as.matrix(cbind(1,power=logit(c(0.01,0.05,0.1,0.25,0.5,0.75,0.9,0.95,0.99))))
ZkronX <- Z %x% X
vect_y <- as.matrix(PowerThresholds) ; dim(vect_y) <- c(nrow(vect_y)*ncol(vect_y),1L)
rownames(vect_y) <- paste(rep(rownames(PowerThresholds),ncol(PowerThresholds)),
                          rep(colnames(PowerThresholds),each=nrow(PowerThresholds)),sep=" -> ")
dimnames(ZkronX) <- list(paste(rep(rownames(X),nrow(Z)),rep(rownames(Z),each=nrow(X)),sep=" -> "),
                         paste(rep(colnames(X),ncol(Z)),rep(colnames(Z),each=ncol(X)),sep=" -> "))
summary(lm(vect_y~ZkronX[,-1L]))
### Boff! pas très sensible de toutes façons.
cbind(Conditions[Conditions[,"Test"]=="permutations",-1L],PowerThresholds[Conditions[,"Test"]=="permutations",])
cbind(Conditions[Conditions[,"Test"]=="parametric",-1L],PowerThresholds[Conditions[,"Test"]=="parametric",])
#
#
### Exemples:
Example <- list()
### Exemple: les poissons du Doubs:
Example[["Doubs"]] <- list()
data(Doubs)
# range(Doubs.geo[,"DFS"])
# summary(diff(Doubs.geo[,"DFS"]))
#
Doubs.geo <- Doubs.geo[-8L,] ; Doubs.fish <- Doubs.fish[-8L,] ; Doubs.env <- Doubs.env[-8L,]
Example[["Doubs"]]$map <- eigenmap(x=Doubs.geo[,"DFS"])
Example[["Doubs"]]$trans <- sqrt(Doubs.fish / rowSums(Doubs.fish))
Example[["Doubs"]]$mca <- MCA(Y=Example[["Doubs"]]$trans, X=Doubs.env, emobj=Example[["Doubs"]]$map)
Example[["Doubs"]]$mca_pertest <- permute.mca(Example[["Doubs"]]$mca)
summary(Example[["Doubs"]]$mca_pertest)
par(mar = c(6,4,2,4))
plot(Example[["Doubs"]]$mca_pertest, las = 2)
Example[["Doubs"]]$mca_pertest$UpYXcb$C # Array containing the codependence coefficients
Example[["Doubs"]]$spmeans <- colMeans(Example[["Doubs"]]$trans)
Example[["Doubs"]]$pca <- svd(Example[["Doubs"]]$trans - rep(Example[["Doubs"]]$spmeans,each=nrow(Doubs.fish)))
Example[["Doubs"]]$x <- seq(0,450,1)
Example[["Doubs"]]$newdists <- matrix(NA, length(Example[["Doubs"]]$x), nrow(Doubs.geo))
for(i in 1L:nrow(Example[["Doubs"]]$newdists))
  Example[["Doubs"]]$newdists[i,] <- abs(Doubs.geo[,"DFS"] - Example[["Doubs"]]$x[i])
rm(i)
Example[["Doubs"]]$prd <- predict(Example[["Doubs"]]$mca_pertest,
                                  newdata=list(target = eigenmap.score(Example[["Doubs"]]$map, Example[["Doubs"]]$newdists)))
Example[["Doubs"]]$Uprd <- (Example[["Doubs"]]$prd - rep(Example[["Doubs"]]$spmeans, each = nrow(Example[["Doubs"]]$prd))) %*% Example[["Doubs"]]$pca$v %*% diag(Example[["Doubs"]]$pca$d^-1)
par(mar = c(5,5,2,5)+0.1)
plot(y = Example[["Doubs"]]$pca$u[,1L], x = Doubs.geo[,"DFS"], pch = 21L, bg = "red",
     ylab = "PCA1 loadings", xlab = "Distance from river source (km)")
lines(y = Example[["Doubs"]]$Uprd[,1L], x = Example[["Doubs"]]$x, col=2, lty = 1)
#
plot(y = Example[["Doubs"]]$pca$u[,2L], x = Doubs.geo[,"DFS"], pch = 21L, bg = "red",
     ylab = "PCA2 loadings", xlab = "Distance from river source (km)")
lines(y = Example[["Doubs"]]$Uprd[,2L], x = Example[["Doubs"]]$x, col=2, lty = 1)
#
### Affichage de la truite brune seule:
plot(y = Example[["Doubs"]]$pca$u[,1L], x = Doubs.geo[,"DFS"], pch = 21L, bg = "red",
     ylab = "PCA2 loadings", xlab = "Distance from river source (km)")
lines(y = Example[["Doubs"]]$Uprd[,1L], x = Example[["Doubs"]]$x, col=2, lty = 1)
#
Example[["Doubs"]]$prdcmp <- predict(Example[["Doubs"]]$mca_pertest,
                                     newdata=list(target = eigenmap.score(Example[["Doubs"]]$map, Example[["Doubs"]]$newdists)),
                                     components=TRUE)
Example[["Doubs"]]$Uprdcmp <- array(NA,dim=dim(Example[["Doubs"]]$prdcmp$components))
for(i in 1L:dim(Example[["Doubs"]]$prdcmp$components)[3L])
  Example[["Doubs"]]$Uprdcmp[,,i] <- Example[["Doubs"]]$prdcmp$components[,,i] %*% Example[["Doubs"]]$pca$v %*% diag(Example[["Doubs"]]$pca$d^-1)
rm(i)
#
Example[["Doubs"]]$cols <- rainbow(1100)[1L:1000]
#
X11(width=7.25,height=3.7)
par(mar=c(4.5,4.5,1.5,1.5),fig=c(0,0.5,0,1))
plot(NA, xlim=range(Example[["Doubs"]]$pca$u[,1L],Example[["Doubs"]]$pca$v[,1L]),las=2L,
     ylim=range(Example[["Doubs"]]$pca$u[,2L],Example[["Doubs"]]$pca$v[,2L]),
     xlab=paste("PCA1 (",100*round((Example[["Doubs"]]$pca$d[1L]^2)/sum(Example[["Doubs"]]$pca$d^2),2),"%)",sep=""),
     ylab=paste("PCA2 (",100*round((Example[["Doubs"]]$pca$d[2L]^2)/sum(Example[["Doubs"]]$pca$d^2),2),"%)",sep=""),pch=21)
text("A",font=2L,x=-0.27,y=0.26,cex=1.25)
text(rownames(Doubs.fish),x=Example[["Doubs"]]$pca$u[,1L],y=Example[["Doubs"]]$pca$u[,2L],xlab="PCA1",ylab="PCA2",pch=21)
text(colnames(Doubs.fish),x=Example[["Doubs"]]$pca$v[,1L],y=Example[["Doubs"]]$pca$v[,2L],cex=0.5,col="red")
par(mar=c(1.5,5,1.5,1.5),fig=c(0.5,1,0.55,1),new=TRUE)
plot(y = Example[["Doubs"]]$pca$u[,1L], x = Doubs.geo[,"DFS"], pch = 21L, bg = "white", ylab = "PCA1\nloadings",
     xlab = "", ylim = range(Example[["Doubs"]]$pca$u[,1L],Example[["Doubs"]]$pca$v[,1L]), las = 1L)
lines(y = Example[["Doubs"]]$Uprd[,1L], x = Example[["Doubs"]]$x, col = 2L, lty = "solid")
lines(y = Example[["Doubs"]]$Uprdcmp[,1L,1L], x = Example[["Doubs"]]$x, col = 1L, lty = "22")
lines(y = Example[["Doubs"]]$Uprdcmp[,1L,2L], x = Example[["Doubs"]]$x, col = 1L, lty = "44")
lines(y = Example[["Doubs"]]$Uprdcmp[,1L,3L], x = Example[["Doubs"]]$x, col = 1L, lty = "4222")
lines(y = Example[["Doubs"]]$Uprdcmp[,1L,4L], x = Example[["Doubs"]]$x, col = 1L, lty = "422222")
legend(legend=expression(paste("MEM1 & ",italic(flow)),paste("MEM4 & ",italic(BOD)),paste("MEM3 & [",NH[4]^"-","]"),
                         paste("MEM2 & [",O[2],"]"),Total),
       lty=c("22","44","4222","422222","solid"),x=220,y=0.45,cex=0.4,col=c(1,1,1,1,2))
text("B",font=2L,x=45,y=0.385,cex=1.25)
par(mar=c(2,5,1.5,1.5),fig=c(0.5,1,0.1,0.55),new=TRUE)
plot(y = Example[["Doubs"]]$pca$u[,2L], x = Doubs.geo[,"DFS"], pch = 21L, bg = "white", ylab = "PCA2\nloadings",
     xlab = "", ylim = range(Example[["Doubs"]]$pca$u[,2L],Example[["Doubs"]]$pca$v[,2L]), las = 1L)
lines(y = Example[["Doubs"]]$Uprd[,2L], x = Example[["Doubs"]]$x, col = 2L, lty = "solid")
lines(y = Example[["Doubs"]]$Uprdcmp[,2L,1L], x = Example[["Doubs"]]$x, col = 1L, lty = "22")
lines(y = Example[["Doubs"]]$Uprdcmp[,2L,2L], x = Example[["Doubs"]]$x, col = 1L, lty = "44")
lines(y = Example[["Doubs"]]$Uprdcmp[,2L,3L], x = Example[["Doubs"]]$x, col = 1L, lty = "4222")
lines(y = Example[["Doubs"]]$Uprdcmp[,2L,4L], x = Example[["Doubs"]]$x, col = 1L, lty = "422222")
mtext("Distance from river source (km)",side=1L,line=2.25)
text("C",font=2L,x=45,y=0.185,cex=1.25)
# summary(Example[["Doubs"]]$mca_pertest)
# dev.copy2eps(file = "./Images/Example - Doubs.eps") ; dev.off()
#
Example[["Mite"]] <- list()
data(Mite)
Example[["Mite"]]$map <- eigenmap(x = mite.geo)
Example[["Mite"]]$trans <- sqrt(mite.species / rowSums(mite.species))
Example[["Mite"]]$mca <- MCA(Y = Example[["Mite"]]$trans, X = mite.env[,-c(8L,9L,10L,13L)], emobj = Example[["Mite"]]$map)
Example[["Mite"]]$mca_pertest <- permute.mca(Example[["Mite"]]$mca, response.tests = TRUE)
summary(Example[["Mite"]]$mca_pertest)
plot(Example[["Mite"]]$mca_pertest, las = 2, lwd = 2)
plot(Example[["Mite"]]$mca_pertest, col = rainbow(1200)[1L:1000], las = 3, lwd = 4, main = "Codependence diagram", col.signif = "white")
Example[["Mite"]]$rng <- list(x = seq(min(mite.geo[,"x"]) - 0.1, max(mite.geo[,"x"]) + 0.1, 0.05),
                              y = seq(min(mite.geo[,"y"]) - 0.1, max(mite.geo[,"y"]) + 0.1, 0.05))
Example[["Mite"]]$grid <- cbind(x = rep(Example[["Mite"]]$rng[["x"]], length(Example[["Mite"]]$rng[["y"]])),
                                y = rep(Example[["Mite"]]$rng[["y"]], each = length(Example[["Mite"]]$rng[["x"]])))
Example[["Mite"]]$newdists <- matrix(NA, nrow(Example[["Mite"]]$grid), nrow(mite.geo))
for(i in 1L:nrow(Example[["Mite"]]$grid))
  Example[["Mite"]]$newdists[i,] <- ((mite.geo[,"x"] - Example[["Mite"]]$grid[i,"x"])^2 + (mite.geo[,"y"] - Example[["Mite"]]$grid[i,"y"])^2)^0.5
rm(i)
#
Example[["Mite"]]$spmeans <- colMeans(Example[["Mite"]]$trans)
Example[["Mite"]]$pca <- svd(Example[["Mite"]]$trans - rep(Example[["Mite"]]$spmeans, each = nrow(Example[["Mite"]]$trans)))
Example[["Mite"]]$prd <- predict(Example[["Mite"]]$mca_pertest,
                                 newdata = list(target = eigenmap.score(Example[["Mite"]]$map, Example[["Mite"]]$newdists)))
Example[["Mite"]]$Uprd <- (Example[["Mite"]]$prd - rep(Example[["Mite"]]$spmeans, each = nrow(Example[["Mite"]]$prd))) %*% Example[["Mite"]]$pca$v %*% diag(Example[["Mite"]]$pca$d^-1)
Example[["Mite"]]$prmatlist <- list()
Example[["Mite"]]$prmatlist[["PCA1"]] <- Example[["Mite"]]$Uprd[,1L]
dim(Example[["Mite"]]$prmatlist[["PCA1"]]) <- c(length(Example[["Mite"]]$rng$x),length(Example[["Mite"]]$rng$y))
Example[["Mite"]]$prmatlist[["PCA2"]] <- Example[["Mite"]]$Uprd[,2L]
dim(Example[["Mite"]]$prmatlist[["PCA2"]]) <- c(length(Example[["Mite"]]$rng$x),length(Example[["Mite"]]$rng$y))
#
Example[["Mite"]]$prdcmp <- predict(Example[["Mite"]]$mca_pertest,
                                    newdata=list(target = eigenmap.score(Example[["Mite"]]$map, Example[["Mite"]]$newdists)),
                                    components=TRUE)
Example[["Mite"]]$Uprdcmp <- array(NA,dim=dim(Example[["Mite"]]$prdcmp$components))
for(i in 1L:dim(Example[["Mite"]]$prdcmp$components)[3L])
  Example[["Mite"]]$Uprdcmp[,,i] <- Example[["Mite"]]$prdcmp$components[,,i] %*% Example[["Mite"]]$pca$v %*% diag(Example[["Mite"]]$pca$d^-1)
rm(i)
#
Example[["Mite"]]$rngcols <- c(-1,1)*max(abs(range(Example[["Mite"]]$pca$u[,1L:2L])))
Example[["Mite"]]$cols <- c(rgb(seq(0,0.75,length.out=200),seq(0,0.75,length.out=200),1),rgb(1,1,1),rgb(1,seq(0.75,0,length.out=200),seq(0.75,0,length.out=200)))
#
### summary(Example[["Mite"]]$mca_pertest)
#
X11(width=7.25,height=7.25)
par(mar=c(4.5,4.5,3.0,3.0))
xpnd <- 0.375
plot(NA, xlim=Example[["Mite"]]$rngcols,las=2L, ylim=Example[["Mite"]]$rngcols,asp=1,
     xlab=paste("PCA1 (",100*round((Example[["Mite"]]$pca$d[1L]^2)/sum(Example[["Mite"]]$pca$d^2),2),"%)",sep=""),
     ylab=paste("PCA2 (",100*round((Example[["Mite"]]$pca$d[2L]^2)/sum(Example[["Mite"]]$pca$d^2),2),"%)",sep=""),pch=21)
text(paste(1L:nrow(Example[["Mite"]]$trans)),x=Example[["Mite"]]$pca$u[,1L],y=Example[["Mite"]]$pca$u[,2L],xlab="PCA1",ylab="PCA2",
     pch=21,cex=0.85)
text(paste("Sp",1:ncol(mite.species),sep=""),x=xpnd*Example[["Mite"]]$pca$v[,1L],y=xpnd*Example[["Mite"]]$pca$v[,2L],cex=1,col="red")
abline(v=0,lty=3L) ; abline(h=0,lty=3L)
x <- seq(Example[["Mite"]]$rngcols[1L],Example[["Mite"]]$rngcols[2L],length.out=length(Example[["Mite"]]$cols)+1L)
for(i in seq(0.32,0.36,0.0005)) {
  segments(x0=x[-length(x)],y0=rep(i,length(Example[["Mite"]]$cols)),x1=x[-1L],y1=rep(i,length(Example[["Mite"]]$cols)),
           col=Example[["Mite"]]$cols,lwd=1,xpd=TRUE,lend=2)
}
for(i in seq(0.32,0.36,0.0005)) {
  segments(x0=rep(i,length(Example[["Mite"]]$cols)),y0=x[-length(x)],x1=rep(i,length(Example[["Mite"]]$cols)),y1=x[-1L],
           col=Example[["Mite"]]$cols,lwd=1,xpd=TRUE,lend=2)
}
#
# dev.copy2eps(file = "./Images/Mites - PCA.eps") ; dev.off()
#
X11(width=7.25,height=7.25)
par(mar=c(4.5,4.5,3.0,3.0))
xpnd <- 0.375
plot(NA, xlim=Example[["Mite"]]$rngcols,las=2L, ylim=Example[["Mite"]]$rngcols,asp=1,
     xlab=paste("PCA1 (",100*round((Example[["Mite"]]$pca$d[1L]^2)/sum(Example[["Mite"]]$pca$d^2),2),"%)",sep=""),
     ylab=paste("PCA2 (",100*round((Example[["Mite"]]$pca$d[2L]^2)/sum(Example[["Mite"]]$pca$d^2),2),"%)",sep=""),pch=21)
text(paste(1L:nrow(Example[["Mite"]]$trans)),x=Example[["Mite"]]$pca$u[,1L],y=Example[["Mite"]]$pca$u[,2L],xlab="PCA1",ylab="PCA2",
     pch=21,cex=0.85)
a <- atan2(Example[["Mite"]]$pca$v[,2L],Example[["Mite"]]$pca$v[,1L])
idx <- sort(a,decreasing=TRUE,index.return=TRUE)$ix
circ <- seq(pi,-pi,length.out=length(a)+1L)[-length(a)-1L]
rad <- 0.28
text(paste("Sp",1:ncol(mite.species),sep="")[idx],x=rad*cos(circ),y=rad*sin(circ),cex=1,col="red")
arrows(x1=xpnd*Example[["Mite"]]$pca$v[idx,1L],y1=xpnd*Example[["Mite"]]$pca$v[idx,2L],x0=0.95*rad*cos(circ),y0=0.95*rad*sin(circ))
#### Les lignes se croisent car la forme décrite par le nuage de points 
#### Oh boy! laissons faire, trop complexe. Il faudrait faire une série de coques convexes et y aller par épuisement des
#### points à la périphérie. Trop complexe pour être développé ici.
#
pc <- 2L
X11(width=7.25,height=4.0)
par(mar=c(3,2.0,3,1.0),fig=c(0,0.2,0,1))
image(x = Example[["Mite"]]$rng[["x"]], y = Example[["Mite"]]$rng[["y"]], z = Example[["Mite"]]$prmatlist[[paste("PCA",pc,sep="")]],
      cex.main=0.75, zlim=Example[["Mite"]]$rngcols,col=Example[["Mite"]]$cols, xlab="", ylab="", asp=1,
      las=2, main = paste("PCA",pc,"\nloading",sep=""), axes=FALSE, xpd=TRUE)
points(x = mite.geo[,"x"], y = mite.geo[,"y"], pch=21L,
       bg = Example[["Mite"]]$cols[1L+round((length(Example[["Mite"]]$cols)-1L)*(Example[["Mite"]]$pca$u[,pc]-Example[["Mite"]]$rngcols[1L])/(Example[["Mite"]]$rngcols[2L]-Example[["Mite"]]$rngcols[1L]),0L)])
axis(2L,at=c(0,3),label=c("","")) ; arrows(-0.5,0.05,-0.5,2.95,code=3,xpd=TRUE,length=0.05)
rect(-0.4,1,-1.2,2,border="white",col="white",bg="white",xpd=TRUE) ; text("3m",x=-0.6,y=1.5,srt=90,xpd=TRUE)
mtext("Shore",at=0.1,side=2L,line=-1.25,outer=TRUE,font=2L)
mtext("Lake",at=0.9,side=2L,line=-1.25,outer=TRUE,font=2L)
par(mar=c(3.5,1.25,3,1.75),fig=c(0.6,0.8,0,1),new=TRUE)
# tmp <- names(Example[["Mite"]]$mca_pertest$test$significant$X)
# tmp <- substr(tmp,3L,nchar(tmp))
# tmp <- paste(tmp,colnames(Example[["Mite"]]$mca_pertest$data$X)[Example[["Mite"]]$mca_pertest$test$significant$X],sep="\n&\n")
tmp <- expression(atop("MEM1 &",italic(WaterCont)),atop("MEM4 &",paste(italic(Shrub),":",italic(Many))),
                  atop("MEM2 &",paste(italic(Subs),":",italic(Sphagnum),1)),atop("MEM3 &",paste(italic(Topo),":",italic(Hummock))))
par(mar=c(3,1.75,3,1.25),fig=c(0.2,0.4,0,1),new=TRUE)
image(x = Example[["Mite"]]$rng[["x"]], y = Example[["Mite"]]$rng[["y"]], main = tmp[1L], cex.main = 0.75, xpd=TRUE, axes=FALSE,
      z = matrix(Example[["Mite"]]$Uprdcmp[,pc,1L],length(Example[["Mite"]]$rng[["x"]]),length(Example[["Mite"]]$rng[["y"]])),
      zlim=Example[["Mite"]]$rngcols,col=Example[["Mite"]]$cols, xlab="", ylab="", asp=1, las=2)
points(x = mite.geo[,"x"], y = mite.geo[,"y"], pch=21L,
       bg = gray(1-(mite.env[,"WatrCont"] - min(mite.env[,"WatrCont"])) / (max(mite.env[,"WatrCont"]) - min(mite.env[,"WatrCont"]))))
par(mar=c(3,1.5,3,1.5),fig=c(0.4,0.6,0,1),new=TRUE)
image(x = Example[["Mite"]]$rng[["x"]], y = Example[["Mite"]]$rng[["y"]], main = tmp[2L], cex.main = 0.75, xpd=TRUE, axes=FALSE,
      z = matrix(Example[["Mite"]]$Uprdcmp[,pc,2L],length(Example[["Mite"]]$rng[["x"]]),length(Example[["Mite"]]$rng[["y"]])),
      zlim=Example[["Mite"]]$rngcols,col=Example[["Mite"]]$cols, xlab="", ylab="", asp=1, las=2)
points(x = mite.geo[,"x"], y = mite.geo[,"y"], pch=21L, bg = gray(1-mite.env[,"Shrub:Many"]))
par(mar=c(3,1.25,3,1.75),fig=c(0.6,0.8,0,1),new=TRUE)
image(x = Example[["Mite"]]$rng[["x"]], y = Example[["Mite"]]$rng[["y"]], main = tmp[3L], cex.main = 0.75, xpd=TRUE, axes=FALSE,
      z = matrix(Example[["Mite"]]$Uprdcmp[,pc,3L],length(Example[["Mite"]]$rng[["x"]]),length(Example[["Mite"]]$rng[["y"]])),
      zlim=Example[["Mite"]]$rngcols,col=Example[["Mite"]]$cols, xlab="", ylab="", asp=1, las=2)
points(x = mite.geo[,"x"], y = mite.geo[,"y"], pch=21L, bg = gray(1-mite.env[,"Substrate:Sphagn1"]))
par(mar=c(3,1.0,3,2.0),fig=c(0.8,1,0,1),new=TRUE)
image(x = Example[["Mite"]]$rng[["x"]], y = Example[["Mite"]]$rng[["y"]], main = tmp[4L], cex.main = 0.75, xpd=TRUE, axes=FALSE,
      z = matrix(Example[["Mite"]]$Uprdcmp[,pc,4L],length(Example[["Mite"]]$rng[["x"]]),length(Example[["Mite"]]$rng[["y"]])),
      zlim=Example[["Mite"]]$rngcols,col=Example[["Mite"]]$cols, xlab="", ylab="", asp=1, las=2)
points(x = mite.geo[,"x"], y = mite.geo[,"y"], pch=21L, bg = gray(1-mite.env[,"Topo:Hummock"]))
rm(tmp)
# dev.copy2eps(file = paste("./Images/Mites - MCA - PCA",pc,".eps",sep="")) ; dev.off()
#
### Fin des exemples.
#
### Local vs local mca
mindist <- 0.4 ; maxlocal <- 0.12
N <- 10L ; XY <- data.frame(X=runif(1,maxlocal-1,1-maxlocal),Y=runif(1,maxlocal-1,1-maxlocal))
plot(Y~X,data=XY,xlim=c(-1,1),ylim=c(-1,1))
xy <- list(x=XY[1L,"X"],y=XY[1L,"Y"])
for(i in 2L:N) {
  # i <- 2L
  while(any(sqrt((XY[,"X"]-xy$x)^2+(XY[,"Y"]-xy$y)^2)<mindist))
    xy <- list(x=runif(1,maxlocal-1,1-maxlocal),y=runif(1,maxlocal-1,1-maxlocal))
  XY[i,] <- c(xy$x,xy$y)
  points(x=xy$x,y=xy$y)
}
# min(dist(XY))
cols <- rainbow(N)
XY2 <- data.frame(P=numeric(),X=numeric(),Y=numeric())
for(i in 1L:N) {
  # i <- 1L
  K <- round(runif(1L,7,17))
  for(j in 1L:K) {
    xy <- list(x=Inf,y=Inf)
    while(sqrt((XY[i,"X"]-xy$x)^2+(XY[i,"Y"]-xy$y)^2)>maxlocal)
      xy <- list(x=runif(1,XY[i,"X"]-maxlocal,XY[i,"X"]+maxlocal),y=runif(1,XY[i,"Y"]-maxlocal,XY[i,"Y"]+maxlocal))
    XY2 <- rbind(XY2,c(i,xy$x,xy$y))
    points(x=xy$x,y=xy$y,pch=21,bg=cols[i])
  }
}
colnames(XY2) <- c("P","X","Y")
XY2[,1L] <- as.factor(LETTERS[XY2[,1L]])
# summary(XY2)
#
XY <- data.frame(X=tapply(XY2[,2L],XY2[,1L],mean),Y=tapply(XY2[,3L],XY2[,1L],mean))
XY3 <- cbind(XY2[,1L],XY[as.character(XY2[,1L]),])
rownames(XY3) <- NULL
emap <- list(list(),global=eigenmap(as.matrix(XY3[,2L:3L])),local=list())
for(i in unique(XY3[,1L]))
  emap$local[[i]] <- eigenmap(as.matrix(XY2[XY2[,1L]==i,2L:3L]))
#
emap[[1L]] <- emap$global
emap[[1L]]$coordinates <- XY2
emap[[1L]]$colWbar <- NULL
emap[[1L]]$MW <- NULL
for(i in names(emap$local)) {
  emap[[1L]]$D[XY2[,1L]==i,XY2[,1L]==i] <- emap$local[[i]]$D
  emap[[1L]]$W[XY2[,1L]==i,XY2[,1L]==i] <- emap$local[[i]]$W
  tmp <- matrix(0,nrow(emap[[1L]]$U),ncol(emap$local[[i]]$U),
                dimnames=list(rownames(emap[[1L]]$U),paste(colnames(emap$local[[i]]$U),i,sep="-")))
  tmp[XY2[,1L]==i,] <- emap$local[[i]]$U
  emap[[1L]]$U <- cbind(emap[[1L]]$U,tmp)
  emap[[1L]]$lambda <- c(emap[[1L]]$lambda,emap$local[[i]]$lambda)
} ; rm(tmp,i)
ord <- sort(emap[[1L]]$lambda,decreasing=TRUE,index.return=TRUE)$ix
emap[[1L]]$U <- emap[[1L]]$U[,ord] ; emap[[1L]]$lambda <- emap[[1L]]$lambda[ord]
rm(ord)
# round(t(emap[[1L]]$U)%*%emap[[1L]]$U,5)
# Wc <- emap[[1L]]$U%*%diag(emap[[1L]]$lambda)%*%t(emap[[1L]]$U)
# ev <- eigen(Wc)  # La matrice ne se redécompose pas entièrement
# round(ev$values[-121L]-emap[[1L]]$lambda,8)
# round(ev$vectors[,1L]-emap[[1L]]$U[,1L],8)
# round(ev$vectors[,10L]-emap[[1L]]$U[,10L],8)
# round(ev$vectors[,11L]-emap[[1L]]$U[,11L],8)
# rm(Wc,ev)
#
### Discussion: Doubs 2
Example[["Doubs2"]] <- list()
Doubs.env2 <- cbind(Doubs.env[,1L:5L],N=Doubs.env[,"nit"]+Doubs.env[,"amm"],
                    ATNR=100*Doubs.env[,"amm"]/(Doubs.env[,"nit"]+Doubs.env[,"amm"]),Doubs.env[,8L:9L])
Example[["Doubs2"]]$map <- eigenmap(x=Doubs.geo[,"DFS"])
Example[["Doubs2"]]$trans <- sqrt(Doubs.fish / rowSums(Doubs.fish))
Example[["Doubs2"]]$mca <- MCA(Y=Example[["Doubs2"]]$trans, X=Doubs.env2, emobj=Example[["Doubs2"]]$map)
Example[["Doubs2"]]$mca_pertest <- permute.mca(Example[["Doubs2"]]$mca)
summary(Example[["Doubs2"]]$mca_pertest)
summary(Example[["Doubs"]]$mca_pertest)
### Le rapport d'ammonium sur nitrate 
#
