#
init <- function() {
  library(codep)
  library(RMySQL)
  dbd1 <<- dbDriver("MySQL")       # Open database driver.
  con1 <<- dbConnect(dbd1)
  dbSendQuery(con1,"USE MCASims")
  pid <<- Sys.getpid()
}
#
