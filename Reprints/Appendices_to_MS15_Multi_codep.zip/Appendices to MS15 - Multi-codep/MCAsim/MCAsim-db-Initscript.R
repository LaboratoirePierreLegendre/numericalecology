#
### Generates the simulation table into a MySQL DB.
#
library(RMySQL)
dbd1 <- dbDriver("MySQL")
con1 <- dbConnect(dbd1)
dbSendQuery(con1,"USE MCASims")
#
N <- c(10L,25L,50L,100L,250L,500L,1000L)
M <- list(c(1L,2L,3L,5L),
          c(1L,3L,5L,10L),
          c(1L,5L,10L,20L),
          c(1L,10L,20L,50L),
          c(1L,20L,50L,100L),
          c(1L,50L,100L,250L),
          c(1L,100L,250L,500L))
for(i in 1L:100) {
  # i <- 1L
  for(j in 1L:length(N)) {
    # j <- 1L
    Nsites <- N[j]
    for(k in 1L:length(M[[j]])) {
      # k <- 1L
      Nspecies <- M[[j]][k]
      dbSendQuery(con1,paste("INSERT INTO Simulations (Test,Nsites,Nspecies,Done,Total) VALUES ('parametric',",
                             Nsites,",",Nspecies,",0,100)",sep=""))
      if(Nsites<=100)
        dbSendQuery(con1,paste("INSERT INTO Simulations (Test,Nsites,Nspecies,Done,Total) VALUES ('permutations',",
                               Nsites,",",Nspecies,",0,100)",sep=""))
    }
  }
}
#
