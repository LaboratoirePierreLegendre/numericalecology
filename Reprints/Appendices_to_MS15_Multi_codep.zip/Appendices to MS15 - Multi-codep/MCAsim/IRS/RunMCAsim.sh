#!/bin/bash

echo 'Run simulation script in the background'

R CMD BATCH MCAsim-IndepRunScript.R MCAsim-IndepRunScript_PROCESS1.OUT &
R CMD BATCH MCAsim-IndepRunScript.R MCAsim-IndepRunScript_PROCESS2.OUT &
R CMD BATCH MCAsim-IndepRunScript.R MCAsim-IndepRunScript_PROCESS3.OUT &
R CMD BATCH MCAsim-IndepRunScript.R MCAsim-IndepRunScript_PROCESS4.OUT &
R CMD BATCH MCAsim-IndepRunScript.R MCAsim-IndepRunScript_PROCESS5.OUT &
R CMD BATCH MCAsim-IndepRunScript.R MCAsim-IndepRunScript_PROCESS6.OUT &
R CMD BATCH MCAsim-IndepRunScript.R MCAsim-IndepRunScript_PROCESS7.OUT &
R CMD BATCH MCAsim-IndepRunScript.R MCAsim-IndepRunScript_PROCESS8.OUT &

