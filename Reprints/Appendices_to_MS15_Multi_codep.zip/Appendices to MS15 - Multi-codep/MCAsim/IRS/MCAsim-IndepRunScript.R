#
### Script de simulation
### Simulation script
library(codep)
library(RMySQL)
dbd1 <- dbDriver("MySQL")
con1 <- dbConnect(dbd1)
dbSendQuery(con1,"USE MCASims")
pid <- Sys.getpid()
while(TRUE) {
  #
  ### Récupération des conditions de simulation dans la base de données MySQL.
  ### Getting the conditions for simulations from the MySQL DB.
  dbSendQuery(con1,paste("UPDATE MCASims.Simulations SET PID=",pid," WHERE isnull(PID) AND Done < Total LIMIT 1",sep=""))
  JOB <- as.list(fetch(dbSendQuery(con1,paste("SELECT * FROM MCASims.Simulations WHERE PID=",pid,";",sep="")),n=-1))
  if(!length(JOB)) break    # Si plus de jobs disponibles, fin de l'exécution. - No more job?: end here.
  #
  ### Génération des cartes de vecteurs propres - Generating eigenvector maps
  MEM1 <- eigenmap(x = 1:JOB$Nsites, weighting = Wf.binary, boundaries = c(0,1))
  #
  for(i in (JOB$Done+1):JOB$Total) {
    # i <- JOB$Done+1
    while(TRUE) {                    # Point 1: pour tester, exécuter le code depuis ici (voir note plus bas) - For testing, run from here (see below)
      while(TRUE) {
        ### Génération des données
        seed <- as.integer(runif(1L) * as.numeric(Sys.time()) + pid)   # Au cas où >1 processus démarreraient simultanément - Avoid two scripts having the same seed
        set.seed(seed)
        sel <- sample(1L:length(MEM1$lambda),size=1L)
        MEM1sel <- MEM1 ; MEM1sel$lambda <- MEM1sel$lambda[sel] ; MEM1sel$U <- MEM1sel$U[,sel,drop=FALSE]
        X <- matrix(rnorm(JOB$Nsites), JOB$Nsites, 1L, dimnames = list(NULL,"x_1"))
        Y <- matrix(rnorm(JOB$Nsites * JOB$Nspecies), JOB$Nsites, JOB$Nspecies, dimnames = list(NULL,paste("Y", 1L:JOB$Nspecies, sep="_")))
        if(JOB$Test=="parametric") {
          MCA1 <- try(test.mca(MCA(Y = Y, X = X, emobj = MEM1sel), response.tests = FALSE))
        } else {
          if(JOB$Test=="permutations") {
            MCA1 <- try(permute.mca(MCA(Y = floor(exp((1.5*(Y-mean(Y)))+mean(Y))), X = X, emobj = MEM1sel), response.tests = FALSE))
          } else {
          stop("Unknown job type (",JOB$Test,")")
          }
        }
        if(class(MCA1)!="try-error")     # On continue tant que les résultats sont corrects - continue while execution succeded, try again otherwise
          break
      }
      typeI <- MCA1$test$global[1L,5L]   # Comme une seule MEM est présente, pas de tests multiples - Only a single MEM, no multiple testing involved
      Yc <- Y - rep(colMeans(Y), each = nrow(Y))
      Yhat <- MEM1sel$U %*% t(MEM1sel$U) %*% Yc
      Yhat <- scale(Yhat,center=FALSE,scale=TRUE)  # Variance moyenne des vecteurs de valeur ajustées standardisée à 1 - Variance of vectors set to 1
      Yres <- matrix(rnorm(nrow(Yhat) * ncol(Yhat), 0, 1), nrow(Yhat), ncol(Yhat))
      Xc <- X - rep(colMeans(X), each = nrow(X))
      Xhat <- MEM1sel$U %*% t(MEM1sel$U) %*% Xc
      Xhat <- scale(Xhat,center=FALSE,scale=TRUE)  # Variance moyenne des vecteurs de valeur ajustées standardisée à 1 - Variance of vectors set to 1
      Xres <- matrix(rnorm(nrow(Xhat) * ncol(Xhat), 0, 1), nrow(Xhat), ncol(Xhat))
      # Tirer un rapport signal:bruit tout en s'assurant qu'il ne sera ni trop petit (< 1:100) ni trop grand (> 10:1)
      # Draw SNR that are neither too small (< 1:100) not too large (> 10:1)
      while(TRUE) {
        r <- runif(2L)
        snr <- r[1L]/sqrt(1-r[1L]^2)
        if(snr > 0.001 && snr < 100) break
      }
      Yc[] <- r[1L] * r[2L] * Yhat + ((1 - r[1L]^2) * (1 - r[2L]^2))^0.5 * Yres
      Xc[] <- r[1L] * (1-r[2L]^2)^0.5 * Xhat + (1-r[1L]^2)^0.5 * r[2L] * Xres
      if(JOB$Test=="parametric") {
        MCA2 <- try(test.mca(MCA(Y = Yc, X = Xc, emobj = MEM1sel), response.tests = FALSE))
      } else {
        if(JOB$Test=="permutations") {
          Yc[] <- rpois(length(Yc),exp(Yc))
          MCA2 <- try(permute.mca(MCA(Y = Yc, X = Xc, emobj = MEM1sel), response.tests = FALSE))
        } else {
        stop("Unknown job type (",JOB$Test,")")
        }
      }
      if(class(MCA2)!="try-error")   # On continue tant que les résultats sont corrects - continue while execution succeded, try again otherwise
        break
    }
    typeII <- MCA2$test$global[1L,5L]
    # cat(typeI,snr,typeII)            # Pour tester, décommenter et exécuter le code depuis le point 1 ci-dessus.
    dbSendQuery(con1,paste("INSERT INTO MCASims.Results (SimID,iteration,seed,selected,typeI,snr,typeII) VALUES (",
                           JOB$SimID,",",i,",",seed,",",sel,",",typeI,",",snr,",",typeII,");",sep=""))
    dbSendQuery(con1,paste("UPDATE MCASims.Simulations SET Done=",i," WHERE PID=",pid,sep=""))
  }
  dbSendQuery(con1,paste("UPDATE MCASims.Simulations SET PID=null WHERE PID=",pid,sep=""))     # Libère la job - Release the job.
}
dbDisconnect(con1)
#
### Révision du 4 mars 2016 pour la version 4 des simulations.
### Last revised on March 4 2016 for simulation version 4.
#
