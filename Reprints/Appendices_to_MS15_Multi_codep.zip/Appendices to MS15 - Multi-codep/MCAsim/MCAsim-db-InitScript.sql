-- PEM Evaluation Database
-- Creation SQL script.
-- Guillaume Guenard, Université de Montréal, Montreal, Canada
-- October 2011
-- DROP DATABASE MCASims;
-- CREATE DATABASE MCASims;

-- Step 1 : That SQL script creates the database

USE MCASims;

DROP TABLE IF EXISTS Simulations;
CREATE TABLE Simulations (
       SimID        Int unsigned NOT NULL AUTO_INCREMENT,    -- An integer to be used as primary key.
       Test         Enum('parametric','permutations'),
       Nsites       Int Unsigned,
       Nspecies     Int Unsigned,
       Done         Int Unsigned,
       Total        Int Unsigned,
       PID          Int Unsigned,
       PRIMARY KEY  (SimID)
);

DROP TABLE IF EXISTS Results;
CREATE TABLE Results (
       ResID        Int unsigned NOT NULL AUTO_INCREMENT,    -- An integer to be used as primary key.
       SimID        Int unsigned,
       iteration    Int unsigned,
       seed         Bigint Unsigned,
       selected     Int unsigned,
       typeI        double,
       snr          double,
       typeII       double,
       PRIMARY KEY  (ResID)
);

-- For clean up
-- UPDATE MCASims.Simulations SET PID=null;
-- UPDATE MCASims.Simulations SET Done=0;

-- Après les simulations:
CREATE INDEX NM USING BTREE ON Simulations (Nsites,Nspecies);


-- To be run as root:
-- CREATE DATABASE MCASims;
-- DROP DATABASE MCASims;

-- To dump the database once it has been created (with implicit user-specific rights granted by the .my.cnf file):
-- mysqldump -u guenardg MCASims | gzip -9 > MCASims-[version].sql.gz
-- To restore:
-- gunzip < MCASims-[version].sql.gz | mysql -u guenardg MCASims
