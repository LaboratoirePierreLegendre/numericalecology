# select.site() function
# 
# Description –
# Function select.site.R selects data for a specified site of the Chesapeake Bay data file 
# and writes the specified data rows into separate files called "fauna", "sediment" and 
# "waterqual", for either the spring survey (S), the fall survey (F) or the spring and 
# fall surveys (SF), over the 13 years of the study. An additional output vector "Dates" 
# shows the selected sampling dates.
#
# Arguments –
# siID – site identifier, from the series of EPA site numbers, from 1 to 204. Ex: siID=36.
# season – "SF", "S", "F" stand for spring & fall, spring only, fall only.
# X1=fauna,X2=sampling,X3=sediment,X4=waterquality – Files in ChesapeakeBay.Maryland.RData
# trim.fauna – if TRUE, remove columns with colSums=0. Do not trim if FALSE.
# silent – Intermediate calculation results are printed if silent=FALSE.
#
# Value –
# • Data files called "fauna", "sediment" and "waterqual", containing data for the 
#   selected site and survey season.
# • An additional output vector "Dates" shows the selected sampling dates.
# 
# Author – Pierre Legendre, Université de Montréal

select.site <- function(
	siID=24, 
	season="SF", 
	X1=fauna, 
	X2=sampling, 
	X3=sediment, 
	X4=waterquality,
	trim.fauna=TRUE,
	silent=TRUE)
{
if(!silent) print(siID)
# Simplify the fauna column names (i.e. the species names) 
colnames(X1) = paste("Sp",1:205,sep=".")

# Available site identifiers in Chesapeake data: factor with classes "1" to "204"
sel = which(sampling$STATION == siID)
if(!silent) cat("length(sel) =",length(sel),"\n")
if(!silent) cat("selected rows = #",sel,"\n")
# 
# Extract the 4 data matrices for site "siID"
		X1.sel = X1[sel,]
		X2.sel = X2[sel,]
		X3.sel = X3[sel,]
		X4.sel = X4[sel,]
		X2.dates = X2$SAMPLE_DATE[sel]
	if(season == "SF") {
		tmp1 = X1.sel               # fauna, 26 dates
		tmp3 = X3.sel
		tmp4 = X4.sel
		# 
		dates = X2.dates
		if(!silent) cat("length(sel) =",length(sel),"\n")
		if(!silent) cat("selected rows SF = #",sel,"\n")
		}
	if(season == "S") {
		spring = seq(1, 25, by=2)
		tmp1 = X1.sel[spring,]      # fauna, 13 spring dates
		tmp3 = X3.sel[spring,]
		tmp4 = X4.sel[spring,]
		# 
		dates = X2.dates[spring]
		if(!silent) cat("length(sel) =",length(sel[spring]),"\n")
		if(!silent) cat("selected rows S = #",sel[spring],"\n")
		}
	if(season == "F") {
		fall = seq(2, 26, by=2)
		tmp1 = X1.sel[fall,]        # fauna, 13 fall dates
		tmp3 = X3.sel[fall,]
		tmp4 = X4.sel[fall,]
		# 
		dates = X2.dates[fall]
		if(!silent) cat("length(sel) =",length(sel[fall]),"\n")
		if(!silent) cat("selected rows F = #",sel[fall],"\n")
		}
	# Fauna: remove columns with colSums=0
	if(trim.fauna) { 
		fauna.sel = tmp1[ ,colSums(tmp1)!=0]
		} else { fauna.sel = tmp1 }
	
# Construct the file names
file.n1 = c("fauna","sediment","waterqual")
names. = NA
if(season == "SF")         seaID = "SF"
	else if(season == "S") seaID = "S"
	else if(season == "F") seaID = "F" 
for(k in 1:3) names. = c(names., paste(file.n1[k], siID, seaID, sep="."))
if(!silent) cat("File names =", names.[-1])
#
out = list(fauna.sel, tmp3, tmp4, dates)
names(out) = c(names.[-1], "Dates")
out
}
