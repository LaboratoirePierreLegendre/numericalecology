# drop.levels() function
# 
# Description –
# This function removes unused levels from factors in sampling data
#
# Argument –
# data – a data.frame containing factors
#
drop.levels <- function(data) 
{
	for (i in 1:ncol(data)) {
		if (is.factor(data[,i])) { data[,i] <- data[,i][, drop=TRUE] } 
	}
return(data)
}
