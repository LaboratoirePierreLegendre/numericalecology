# Spatial analysis of the Gault Nature Reserve vegetation data

                                 # Pierre Legendre, April 2010
                                 # Revised by Olivier Gauthier, April 2017
                                 # Revised by Pierre Legendre, March-April 2021
# ========

# The following packages will be needed
library(spdep)
library(SoDA)
library(ade4)
library(adespatial)
library(vegan)

# Read the Gault data file "Gault_Forest_Community.txt"

gault = read.table(file.choose())   # File "Gault_Forest_Community.txt"

# Divide into three data matrices

gault.LonLat = gault[,3:4]
gault.spe = gault[,5:18]
gault.env = gault[,19:31]

# Transform the species data
# Column "OTHER" will be used in the transformation, but excluded from the analysis
# Required package: vegan

gault.hel = decostand(gault.spe, "hellinger")
# Remove the last colum, "OtherSp"
gault.hel = gault.hel[,-14]
dim(gault.hel)

# Transform the LonLat data into flat Cartesian coordinates 
# Function geoXY() requires the coordinates in the order Latitude-Longitude
# Required package: SoDA

gault.XY = geoXY(gault.LonLat[,2], gault.LonLat[,1])

# ========

# Is there a spatial structure in the multivariate data?
# K-means partitioning

gault.KM = cascadeKM(gault.hel, 2, 15, iter = 1000, criterion="ssi")
plot(gault.KM)   

# Produce maps for 8 partitions, for K = 2 to 9

par(mfrow=c(2,2))
for(gr in 2:5) plot(gault.XY, pch=gault.KM$partition[,(gr-1)], cex=1)
par(mfrow=c(2,2))
for(gr in 6:9) plot(gault.XY, pch=gault.KM$partition[,(gr-1)], cex=1)

# ========

# Is there a significant linear spatial trend in the data?

trend.out = rda(gault.hel, gault.XY)
anova(trend.out, step=1000, perm.max=1000)

# Answer: yes, there is a significant linear spatial trend in the data
# Compute the model residuals

gault.lm = lm(as.matrix(gault.hel) ~ as.matrix(gault.XY)) 
gault.resid = residuals(gault.lm) 

# ========

# 1. First class of MEM model: dbMEM, threshold from minimum spanning tree

# Construct dbMEM eigenfunctions
# Required package: adespatial
dxy <- dist(gault.XY)
gault.MEM = dbmem(dxy)

# Value of the threshold (min distance to keep all sites connected)?
( th <- give.thresh(dxy) )

# Plot the minimum spaning tree (MST)
par(mfrow=c(1,1))
nb1 <- mst.nb(dxy)
nb1
wh1 <- which(as.matrix(dxy)==th,arr.ind=TRUE)
plot(nb1,gault.XY,pch=20,cex=2,lty=3)
lines(gault.XY[wh1[1,],1],gault.XY[wh1[1,],2],lwd=2)
title(main="Maximum distance of the minimum spanning tree in bold")

# Compare the MST to the map in file "Gault forest communities, map.pdf"

# Load the function plot.links() found in file "plot.links.R". 
# Plot the connection edges ≤ the D threshold 'th' on a map of the Gault Reserve
plot.links(gault.XY, thresh=th)

# -----

# MEM analysis of the detrended data

gault.rda.resid = rda(gault.resid, gault.MEM)
anova(gault.rda.resid, step=1000, perm.max=1000)
# Is this model highly significant?

# Selection of significant MEM eigenfunctions

( gault.resid.sel = forward.sel(gault.resid, gault.MEM) )

# -----

# RDA for the 4 selected dbMEM eigenfunctions. See the output file "gault.resid.sel"

gault.rda.resid.sel = rda(gault.resid~., gault.MEM[,gault.resid.sel$order])
anova(gault.rda.resid.sel, step=1000, perm.max=1000)

# Note the adjusted R-square of the dbMEM model
RsquareAdj(gault.rda.resid.sel)

# Test of significance of individual axes. How many axes are significant?
anova(gault.rda.resid.sel,by = "axis", step=1000, perm.max=1000)

# How many axes are significant? You can plot maps of this/these axis/axes

# ========

# 2. Second class of MEM model: connectivity matrix based on geographic distances
#    (radius around points)
#    Information used: links, weights

# Assessment of the relevant distances, based on a multivariate 
# variogram of the detrended data, with 20 distance classes.
# The function variogmultiv is in spacemakeR

gault.vario <- variogmultiv(gault.resid, gault.XY, nclass=20)
gault.vario
plot(gault.vario$d, gault.vario$var, ty='b', pch=20, xlab="Distance", ylab="C(distance)")

# We will explore a range of 10 evenly distributed distances ranging 
# from the MEM threshold (th == 387.7472 m) to 1690 m (centre of class 9
# which is the class with maximum semi-variance in the variogram)
# (slightly more than 4 x threshold)
thresh10 <- seq(th, 1690, le=10)
thresh10

# Create 10 neighbourhood matrices
# In each matrix: all connexions with lengths up to the threshold value
list10nb <- lapply(thresh10, dnearneigh, x=as.matrix(gault.XY), d1=0)

# Display a portion (first 10 sites) of the first neighbourhood matrix (1 is a link)
print(listw2mat(nb2listw(list10nb[[1]], style="B"))[1:10,1:10], digits=1)

# Now we can apply the function test.W() to the 10 neighbourhood matrices
# using binary links only; no weights on the links
gault.thresh.out <- lapply(list10nb, test.W, Y=gault.resid)

# Lowest AIC, best model, threshold distance of best model
gault.thresh.minAIC <- sapply(gault.thresh.out, function(x) min(x$all$AICc, na.rm=TRUE))


min(gault.thresh.minAIC)  # Smallest AICc (AIC of best model among the 10)
which.min(gault.thresh.minAIC) # Number of the model among the 10
thresh10[which.min(gault.thresh.minAIC)]  # Truncation threshold (distance)

# So, the best model (AIC = -180.0793) is with threshold #8. 
# It includes D up to 1400.610 m

# ========

# 3. Third class of MEM model: connectivity matrix based on distances
#    Connection edges weighted by 1-(d/dmax)^y

# Find the best weighting function for the distances
# Distances are ranged to maximum 1, and raised to power y
f2 <- function(D, dmax, y) { 1 - (D/dmax)^y } 

( exponents = c(seq(0.1,1,0.1),2:10) )  # Selected values of exponent y

gault.thresh.f2 <- lapply(list10nb, function(x) test.W(x, Y=gault.resid, f=f2, y=exponents, dmax=max(unlist(nbdists(x, as.matrix(gault.XY)))), xy=as.matrix(gault.XY))) 

# Lowest AIC, best model
gault.f2.minAIC <- sapply(gault.thresh.f2, function(x) min(x$all$AICc, na.rm=TRUE)) 

min(gault.f2.minAIC)         # Smallest AICc (best model among the 10)
# [1] -187.5968
which.min(gault.f2.minAIC)   # Number of the model among the 10
# [1] 1

# So the best model (AIC = -187.5968) is the one with threshold #1, 
# exponent y = 0.5, 12 MEM variables. It includes D up to 387.7472 m
# This model is better than any of the models that used D as weights

# ========

# 4. The champion model is the one with the lowest AIC statistic
#    Extract the champion MEM model
# ************************************

gault.MEM.champ <- unlist(gault.thresh.f2[which.min(gault.f2.minAIC)], recursive=FALSE)
summary(gault.MEM.champ)

dim(gault.MEM.champ$best$MEM)		# Eigenvectors
summary(gault.MEM.champ$best$AIC)
gault.MEM.champ$best$AIC$ord	# MEM variables by order of increasing R2

# MEM variables from best model
MEMid2 <- gault.MEM.champ$best$AIC$ord[1:which.min(gault.MEM.champ$best$AIC$AICc)]
MEMid2.sort = sort(MEMid2)
MEMid2.sort

# Unadjusted R2 of best model
R2.MEMbest <- gault.MEM.champ$best$AIC$R2[which.min(gault.MEM.champ$best$AIC$AICc)]
R2.MEMbest
# [1] 0.3098736

# Adjusted R2 of best model
# RsquareAdj(R2.MEMbest, nrow(gault.resid), length(MEMid2.sort))
RsquareAdj(0.3098736, 119, 12)
# Compare this value to the adjusted R-square of the fist model (dbMEM).

# -----

# dbMEM analysis for the 12 selected MEM eigenfunctions of the champion model

dbmem.out.12 = rda(gault.resid~., gault.MEM.champ$best$MEM[,MEMid2.sort])
# Note the adjusted R-square of this model
RsquareAdj(dbmem.out.12)

# Global test of significance
anova(dbmem.out.12)

# Test of significance of individual axes. How many axes are significant?
anova(dbmem.out.12, by="axis")

# Conclusion –
# The best model is with all connections up to the MEM threshold (387.7472 m)
# and with weights that are 1-(d/dmax)^0.5. It contains 12 MEM variables.

# ========

# 5. Analyse the species data by the environmental data and the best spatial model

# Environmental data: aspect is a circular variable. Transform it 
# to sin(aspect) and cos(aspect), which can be used in linear models

aspect = gault.env[,11]*pi/180  # Transformation of angles into radians
sin.aspect = sin(aspect)
cos.aspect = cos(aspect)
gault.env2 = cbind(gault.env[,1:10],sin.aspect,cos.aspect,gault.env[,12:13])

# -----

# Examine the available environmental variables
# Note that slope is coded in two different ways: classes and degrees
# Which one is the best?

summary(gault.env2)

# Give shorter names to the variables for clearer plots
colnames(gault.env2) = c("Density","Height","Age","Slope","Deposits","Drainage","GeoAge", "GeoDescription","Suite", "Elev","sin.aspect","cos.aspect","Slope_deg","Watershed")

# -----

# Environmental data: Selection of the environmental variables
# You don't have to run the stepwise selection analysis, the results are given below

mod <- rda(gault.resid ~ ., gault.env2)
step.wise = ordistep(rda(gault.resid ~ 1, gault.env2), scope = formula(mod), pstep = 1000, perm.max = 1000)

# The following variables are selected:
# rda(formula = gault.resid ~ Age + Slope + Deposits + Height + Elev, data = gault.env2)

# Selected variables: gault.env2[,c(2:5,10)]

gault.env.sel = gault.env2[,c(2:5,10)]

# Predictive value of these environmental variables on community composition

RsquareAdj(step.wise)
# $r.squared = 0.4432738
# $adj.r.squared = 0.3683299

# -----

# Variation partioning

gault.part.5 = varpart(gault.resid, gault.env.sel, gault.MEM.champ$best$MEM[,MEMid2.sort])

plot(gault.part.5)
gault.part.5

# -----

# RDA of community composition by the environmental variables

rda.res1 = rda(gault.resid ~ .,data=gault.env.sel)

?anova.cca

# Test the significance of the canonical relationship
anova(rda.res1)  

# Test the significance of individual canonical axes
anova(rda.res1, by="axis")  
# How many axes are significant?

# Tests the "partial significance" of each explanatory variable by partial RDA
anova(rda.res1, by="margin")  

# RDA triplot
plot(rda.res1, scaling=1, main="Triplot, Gault Reserve vegetation", display=c("sp","lc","cn"))
spe.sc = scores(rda.res1, choices=1:2, scaling=1, display="sp")
arrows(0, 0, spe.sc[,1], spe.sc[,2], length=0, lty=1, col="red")
text(spe.sc[,1], spe.sc[,2], colnames(gault.hel), col="red", cex=0.8)

RsquareAdj(rda.res1)

# -----

# Plot maps of the significant canonical axes
# Required package: ade4

par(mfrow=c(2,2))
for(i in 1:3) {
   s.value(gault.XY, summary(rda.res1)$sites[,i], addaxes=FALSE, include.origin=FALSE, sub=paste("Axis ",i),csub=1.5) 
   }

# ========
