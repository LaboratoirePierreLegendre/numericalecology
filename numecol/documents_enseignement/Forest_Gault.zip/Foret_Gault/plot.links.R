plot.links <- function(XY, thresh=1, xlim=NULL, ylim=NULL)
#
# Plot a graph from XY = a table of Cartesian coordinates.
# Add lines corresponding to values below a dissimilarity threshold.
#   Pierre Legendre, April 2010
{
D.mat = as.matrix(dist(XY))
par(mai = c(1.0, 1.0, 1.0, 0.5))
plot(XY, type="p", xlim=xlim, ylim=ylim, asp=1, xlab="Easting", ylab="Northing")
text(XY, labels=rownames(XY), pos=2)
title(main = c("Linkage map","D ≤",thresh), family="serif")
n = nrow(XY)
for(j in 1:(n-1)) {
   for(jj in (j+1):n) {
      if(D.mat[j,jj] <= thresh) lines(c(XY[j,1], XY[jj,1]), c(XY[j,2], XY[jj,2]))
      }
   }
}

# Usage in NEwR, Chapter 7 p.304: plot.links(mite.xy, thresh=1.0111)
# Usage: plot.links(gault.XY, thresh=388.4518)
