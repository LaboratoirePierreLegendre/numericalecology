# lda.out: Output file of function MASS::lda()
# groups: Vector of the group assigned to each object (factor or numeric)
# xax: The axis number to be used for abscissa of the plot
# yax: The axis number to be used for ordinate of the plot
# plot.original: If TRUE, colours are original groups, if FALSE 
#                (default), colours are predicted classes
# plot.chull: If TRUE, plot the convex hulls of the original groups 
#             or of the predicted classes
# plot.centroids: If TRUE, plot the centroids (big points) 
#                 with assigned group colours
# plot.env: If TRUE, plot the explanatory variables to the plot (as arrows)
# title: Customized title to be printed above the plot
# mul.coef: Multiplication factor for the length of the variable arrows
#           (some trial and error is needed here)
#
# License: GPL-2
# Authors: François Gillet, Daniel Borcard and Pierre Legendre

ggplotLDA <- function(lda.out,
                      groups,
                      xax = 1,
                      yax = 2,
                      plot.original = FALSE,
                      plot.centroids = TRUE,
                      plot.chull = TRUE,
                      plot.env = TRUE,
                      title = "LDA predicted classes",
                      mul.coef = 2) {
  if (!is.factor(groups)) {
    groups <- as.factor(groups)
  }
  if (!inherits(lda.out, "lda"))
    # if (!"lda" %in% class(lda.out))
    stop("File lda.out was not produced by function MASS::lda()")
  if (min(summary(groups)) < 2)
    stop("There is at least one group with less than two observations")
  
  # Standardized discriminant function coefficients
  coef <- lda.out$scaling |> as.data.frame()
  # Number of canonical axes
  k <- ncol(coef)
  # Number of groups
  lev <- length(levels(groups))
  
  if (xax > k)
    stop("There are not enough canonical axes: change the xax value")
  if (yax > k)
    stop("There are not enough canonical axes: change the yax value")
  
  # Predicted site scores
  Fp <- predict(lda.out)$x |> as.data.frame()
  
  # Compute the original group centroids in LDA space
  centre <- matrix(NA, lev, k)
  for (i in 1:lev) {
    centre[i, ] <-
      apply(Fp[groups == levels(groups)[i], ], 2, mean)
  }
  centre <- data.frame(centre)
  names(centre) <- paste0("LD", 1:k)
  centre <- centre |> 
    mutate(Group = levels(groups))
  
  # Assignment of sites to classes
  Class <- predict(lda.out)$class
  if (!is.factor(Class)) {
    Class <- as.factor(Class)
  }
  
  # Compute the predicted class centroids in LDA space
  centcl <- matrix(NA, lev, k)
  for (i in 1:lev) {
    centcl[i, ] <-
      apply(Fp[Class == levels(Class)[i], ], 2, mean)
  }
  centcl <- data.frame(centcl)
  names(centcl) <- paste0("LD", 1:k)
  centcl <- centcl |> 
    mutate(Group = levels(groups))
  
  # Plot sites coloured according to original or predicted classes
  xlab <- paste("LDA axis", xax)
  ylab <- paste("LDA axis", yax)
  axn <- names(Fp)
  if (plot.original) {
    Group <- groups
    title = "LDA with original groups"
  } else {
    Group <- Class
    title = "LDA with predicted classes"
  }
  pp <- ggplot(Fp, aes(.data[[axn[1]]], .data[[axn[2]]],
                       label = row.names(Fp), 
                       colour = Group)) +
    geom_point(alpha = 0.6) +
    geom_text_repel(size = 3, show.legend = FALSE) +
    geom_vline(xintercept = 0, linetype = "dotted") +
    geom_hline(yintercept = 0, linetype = "dotted") +
    labs(title = title, x = xlab, y = ylab) +
    coord_equal() +
    theme_minimal()
  
  # Draw convex hulls
  if (plot.chull) {
    hull_data <- 
      Fp %>% 
      mutate(Group = Group) %>% 
      group_by(Group) %>% 
      slice(chull(.data[[axn[1]]], .data[[axn[2]]]))
    pp <- pp +
      geom_polygon(data = hull_data,
                   aes(.data[[axn[1]]], 
                       .data[[axn[2]]],
                       fill = Group,
                       colour = Group),
                   alpha = 0.2,
                   inherit.aes = FALSE,
                   show.legend = FALSE)
  }
  
  # Plot centroids of original groups or of LDA predicted classes
  if (plot.centroids) {
    if (plot.original) {
      cent <- centre
    } else {
      cent <- centcl
    }
    pp <- pp +
      geom_point(
        data = cent, 
        aes(.data[[axn[1]]], .data[[axn[2]]], 
            fill = Group), 
        shape = 21, 
        size = 3,
        show.legend = FALSE,
        inherit.aes = FALSE)
  }
  
  # Plot arrows of environmental variables
  if (plot.env) {
    pp <- pp +
      geom_segment(
        data = coef,
        aes(x = 0, y = 0,
            xend = .data[[axn[1]]] * mul.coef,
            yend = .data[[axn[2]]] * mul.coef),
        arrow = arrow(length = unit(0.025, "npc")),
        colour = "black",
        inherit.aes = FALSE) +
      geom_text_repel(
        data = coef,
        aes(x = .data[[axn[1]]] * mul.coef,
            y = .data[[axn[2]]] * mul.coef,
            label = rownames(coef)),
        size = 4,
        colour = "black",
        inherit.aes = FALSE)
  }
 
  pp
}
