#' Non-parametric tests for multiple comparisons with ggplot2
#'
#' Function to perform Kruskal-Wallis (using agricolae::kruskal) with
#' post-hoc multiple comparisons or (paired or unpaired) Wilcoxon test, 
#' and violin plots and/or boxplots with letters.
#' ggplerk() is an adaptation of boxplerk() to ggplot2. 
#' Mean values are added as big points.
#' This function requires agricolae, plyr, ggplot2 and ggpubr libraries.
#' 
#' @author François Gillet, 2024-09-28
#' @param response the numeric response variable (as vector or column name 
#' of a data frame without or with quotes)
#' @param group the explanatory factor (groups, treatments...) or a qualitative 
#' variable that can be converted to a factor (as vector or column name 
#' of a data frame without or with quotes)
#' @param data a data frame containing both response and group variables (optional)
#' @param paired if TRUE and if 2 groups only, then Wilcoxon paired test is 
#' performed (objects are supposed to be ordered twice the same way in the 
#' data frame)
#' @param p.adj correction of p-values for multiple comparisons after 
#' Kruskal-Wallis test (default = "holm", else "none", "bonferroni",...)
#' @violin if TRUE (default) violin plots + boxplots, if FALSE only boxplots
#' @vscale one of "width" (default), "area" or "count" scaling option 
#' for violin plots
#' @param bwidth relative width of boxplots included in violin plots
#' @param varwidth if TRUE, adapt boxplot width to relative group size
#' @param notch if TRUE, add notches to boxes to help multiple comparisons
#' @param bcol fill colour(s); if bcol = "" then boxplots or violin plots are 
#' filled according to a gradient of heat colors based on rank sums
#' @param reorder if TRUE, sort boxplots or violin plots in decreasing 
#' order of the average response
#' @param title title of the plot
#' @param xlab x-axis title (name of the explanatory factor X)
#' @param ylab y-axis title (name of the numeric response variable Y)
#' @return a summary table ($comparison) is printed and violin plots and/or 
#' boxplots ($plot) are drawn with result of the test ($p.value) and, if it is 
#' significant, of post-hoc tests as letters (in decreasing order); the method 
#' applied to adjust p-values is also returned ($p.adjust)
#' @export
#' @examples
#' library(stats)
#' data(InsectSprays)
#'   
#' # Check ANOVA assumptions
#' shapiro.test(resid(aov(InsectSprays$count ~ InsectSprays$spray)))
#' bartlett.test(InsectSprays$count, InsectSprays$spray)
#' 
#' # Since assumptions are NOT met, perform the non-parametric tests:
#' ggplerk(
#'   InsectSprays$count,
#'   InsectSprays$spray,
#'   p.adj = "holm",
#'   ylab = "Count",
#'   xlab = "Spray")

ggplerk <- function(response,
                    group,
                    data = NULL,
                    paired = FALSE,
                    p.adj = "holm",
                    violin = TRUE,
                    vscale = "width",
                    bwidth = 0.25,
                    varwidth = TRUE,
                    notch = FALSE,
                    bcol = NULL,
                    reorder = FALSE,
                    title = NULL,
                    xlab = "X factor",
                    ylab = "Y value") {
  
  if (is.data.frame(data)) {
    X <- substitute(group)
    if (is.symbol(X)) X <- deparse(X)
    X <- data[[X]]
    if (xlab == "X factor") {
      xlab <- deparse1(substitute(group))
    }
    Y <- substitute(response)
    if (is.symbol(Y)) Y <- deparse(Y)
    Y <- data[[Y]]
    if (ylab == "Y value") {
      ylab <- deparse1(substitute(response))
    }
  } else {
    X <- group
    Y <- response
  }
  if (!is.factor(X)) {
    X <- as.factor(X)
  }
  aa <- levels(X)
  data <- data.frame(X, Y)

  tt1 <- matrix(nrow = length(aa), ncol = 7)
  for (i in 1:length(aa)) {
    temp <- Y[X == aa[i]]
    tt1[i, 1] <- mean(temp, na.rm = TRUE)
    tt1[i, 2] <- sd(temp, na.rm = TRUE) / sqrt(length(temp))
    tt1[i, 3] <- sd(temp, na.rm = TRUE)
    tt1[i, 4] <- min(temp, na.rm = TRUE)
    tt1[i, 5] <- max(temp, na.rm = TRUE)
    tt1[i, 6] <- median(temp, na.rm = TRUE)
    tt1[i, 7] <- length(temp)
  }
  tt1 <- as.data.frame(tt1)
  row.names(tt1) <- aa
  colnames(tt1) <- c("mean", "se", "sd", "min", "max", "median", "n")
  
  # Kruskal-Wallis test
  comp <- agricolae::kruskal(Y, X, p.adj = p.adj)
  gror <- comp$groups[aa, ]
  tt1$rank <- gror$Y
  tt1$group <- gror$groups
  
  if (paired == TRUE & length(aa) == 2) {
    pht <- "Paired Wilcoxon test"
    # Sort data by X
    data <- plyr::arrange(data, X)
    # Add an ID for each pair of objects
    data$ID <- rep(1:(length(Y) / length(aa)), length(aa))
    # Long to wide format
    XYw <- reshape(data, direction = "wide",
                   idvar = "ID", timevar = "X")
    # Paired test for class formula
    res <- wilcox.test(Pair(Y.1, Y.2) ~ 1, data = XYw)
    # res <- wilcox.test(Y ~ X, paired = TRUE)
    pp <- res$p.value
    tt1$group <- rep("a", 2)
    if (pp <= 0.05) 
      tt1$group[which(tt1$rank == min(tt1$rank))] <- "b"
  }
  else {
    if (length(aa) == 2) {
      pht <- "Wilcoxon test"
      res <- wilcox.test(Y ~ X)
      pp <- res$p.value
      tt1$group <- rep("a", 2)
      if (pp <= 0.05) 
        tt1$group[which(tt1$rank == min(tt1$rank))] <- "b"
    }
    else {
      pht <- "Kruskal-Wallis test"
      pp <- comp$statistics$p.chisq
    }
  }
  
  if (is.null(bcol)) {
    # bcol <- heat.colors(nrow(tt1), rev = TRUE)[rank(tt1$median)]
    bcol <- hcl.colors(nrow(tt1), palette = "Heat 2",
                       rev = TRUE)[rank(tt1$median)]
  }
  
  if (reorder) xx <- reorder(X, -Y)
  else xx <- X
  
  if(violin) { # default violin plots + boxplots
    p <- ggplot(data = data, 
                aes(xx, Y, 
                    group = X, 
                    # color = X, 
                    fill = X)) +
      geom_violin(
        aes(colour = X),
        alpha = 0.75,
        scale = vscale,
        na.rm = TRUE) +
      geom_boxplot(width = bwidth, 
                   alpha = 0.2, 
                   fill = "black") +
      scale_colour_manual(values = bcol) +
      scale_fill_manual(values = bcol) +
      labs(title = title, x = xlab, y = ylab) +
      theme_minimal() +
      theme(legend.position = "none")
  } else { # only boxplots
    p <- ggplot(data = data, 
                aes(xx, Y, 
                    group = X, 
                    # colour = X, 
                    fill = X)) +
      geom_boxplot(alpha = 0.5,
                   linewidth = 0.5,
                   varwidth = varwidth,
                   notch = notch,
                   outlier.colour = 1,
                   outlier.shape = 1,
                   outlier.alpha = 0.5,
                   na.rm = TRUE) +
      scale_colour_manual(values = bcol) +
      scale_fill_manual(values = bcol) +
      labs(title = title, x = xlab, y = ylab) +
      theme_minimal() +
      theme(legend.position = "none")
  }

  op <- options()
  options(scipen = 4)
  if (pp < 0.001)
    st <- bquote(italic(P) < 0.001)
  else {
    pp2 <- round(pp, 3)
    st <- bquote(italic(P) == .(pp2))
  }
  p <- p + labs(subtitle = bquote(.(pht) ~ ~ ~ ~ ~ ~ .(st)))
  options(op)     # reset all initial options
  
  p <- p + stat_summary(
    geom = "point",
    fun = "mean",
    pch = 21,
    size = 3.5,
    fill = "white",
    alpha = 1) + 
    stat_summary(
      geom = "text",
      label = paste("n =", tt1$n),
      fun = "min",
      size = 3.5,
      colour = "black",
      vjust = 1.5) +
    ylim(min(Y) * 0.9, max(Y) * 1.1)
  
  if (pp <= 0.05) {
    p <- p + stat_summary(
      geom = "text",
      label = tt1$group,
      fun = "max",
      size = 5,
      colour = "black",
      vjust = -0.8)
  }
  
  list(comparison = tt1,
       p.value = pp,
       p.adjust = p.adj,
       plot = p)
}
